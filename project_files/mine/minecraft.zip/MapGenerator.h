#ifndef MAPGENERATOR_H
#define MAPGENERATOR_H

#include "common.h"

class MapGenerator {
	public:
	static void generateMap(int seed);
	static void placeTree(int x, int y, int z);
};

#endif
