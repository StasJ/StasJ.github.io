#include "Button.h"
#include "Application.h"

void Button::update(const float dt)
{
	sf::Vector2i mp = sf::Mouse::getPosition(Application::window);
	const bool md = sf::Mouse::isButtonPressed(sf::Mouse::Left);
	const sf::Vector2<unsigned int> winSize = Application::window.getSize();
	mp.y = winSize.y - mp.y;

	if (over && down && !md)
		callback();
	else if (over && md)
		down = 1;

	if (!md)
		down = 0;
	if (mp.x > pos.x && mp.y > pos.y && mp.x < pos.x+size.x && mp.y < pos.y+size.y)
		over = 1;
	else
		over = 0;
}

void Button::render() const
{
	if (down)
		glColor3f(1,0,0);
	else if (over)
		glColor3f(0,0,1);
	else
		glColor3f(1,1,1);

	glPushMatrix();
	glTranslatef(pos.x, pos.y, 0);
	glBegin(GL_QUADS);
	glVertex2f(0, 0);
	glVertex2f(size.x, 0);
	glVertex2f(size.x, size.y);
	glVertex2f(0, size.y);
	glEnd();
	glPopMatrix();
}
