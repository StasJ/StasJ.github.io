#ifndef ENTITY_H
#define ENTITY_H

#include "common.h"
#include "Vector.h"

struct EntityId {
	const int id;
	EntityId():id(globalId++){}
	operator int() {return id;}
		
	private:
	static int globalId;
};


class Entity {
	public:
		EntityId id;
		Vec3 pos;
		Vec3 vel;
		Vec3 acc;
		Vec3 rot;

		Entity():pos(0),vel(0),acc(0),rot(0){}
		virtual void update(float dt) = 0;
		virtual void saveToFile(FILE *f);
		virtual void loadFromFile(FILE *f);
		virtual void render() = 0;
		virtual void print();
};

#endif
