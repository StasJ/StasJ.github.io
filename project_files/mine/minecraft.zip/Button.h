#ifndef BUTTON_H
#define BUTTON_H

#include "common.h"
#include <functional>
#include "Vector.h"

class Button {
	public:
	
	Vec2 pos;
	Vec2 size;
	std::function<void(void)> callback;
	
	bool down;
	bool over;

	Button(Vec2 pos, Vec2 size, std::function<void(void)> callback)
		: pos(pos), size(size), callback(callback), down(0), over(0) {}
	void update(const float dt);
	void render() const;
};

#endif
