#ifndef WORLD_H
#define WORLD_H

#include "common.h"
#include "Block.h"
#include "Player.h"
#include "Entity.h"
#include "EntityManager.h"

#define MH 64
#define MW 128
#define MD 128
//#define MH 32
//#define MW 32
//#define MD 32
#define MHS 6
#define MWS 7
#define MDS 7

struct TransparentQueueData : public Vec5i {
	TransparentQueueData(int x, int y, int z, int i, int d):Vec5i(x,y,z,i,d) {}
	bool operator<(const TransparentQueueData &rhs) const { return d[4] > rhs.d[4]; }
};

class World {
	public:
	
	static const float gravity;

	static BlockData map[MH * MW * MD];
	static BlockVData vmap[MH * MW * MD];
	static int lmap[MW * MD];
	static std::vector<TransparentQueueData> transparentQueue;
	static Player *player;
	static EntityManager entities;
	static float dt;
	static Vector3i selectedCoord;
	static int selectedFace;
	static bool isSelected;
	static int placeBlockId;
	static bool leftDown;
	static bool rightDown;

	static void init(int seed);
	static void update(float dt);
	static void render();
	static void loadFromFile(const char *path);
	static void saveToFile(const char *path);

	static void updateBlock(const int x, const int y, const int z);
	static void updateBlockNeighbors(const int x, const int y, const int z);
	static void drawBlock(const int x, const int y, const int z, const int i);
	static void drawHighlightedSelect();
	static void handleInput();

	static BlockData getBlock(const int x, const int y, const int z);
	static void setBlock(const int x, const int y, const int z, const BlockData id);
	static void setBlock(const int x, const int y, const int z, const Block *block);
	static void setBlockNU(const int x, const int y, const int z, const BlockData id);
	static void setBlockNU(const int x, const int y, const int z, const Block *block);
	static bool isOpaque(const int x, const int y, const int z);
	static bool isSolid(const int x, const int y, const int z);
	static inline int getIndex(const int x, const int y, const int z);

};

#endif
