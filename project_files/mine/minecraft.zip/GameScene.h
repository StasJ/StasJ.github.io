#ifndef GAMESCENE_H
#define GAMESCENE_H

#include "common.h"
#include "Scene.h"
//#include "WorldMap.h"

class GameScene : public Scene {

	//WorldMap map;

	GameScene();
	~GameScene();

};

#endif
