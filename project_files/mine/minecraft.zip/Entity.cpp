#include "Entity.h"

int EntityId::globalId = 1;

void Entity::print()
{
	printf("Entity [id:%i]", id.id);
	printf("pos");pos.Print();
	printf("vel");vel.Print();
	printf("acc");acc.Print();
	printf("rot");rot.Print();
}

void Entity::saveToFile(FILE *f)
{
	float v[3];
	for (int i=0;i<3;i++)v[i]=pos[i];
	fwrite(v, sizeof(float), 3, f);
	for (int i=0;i<3;i++)v[i]=vel[i];
	fwrite(v, sizeof(float), 3, f);
	for (int i=0;i<3;i++)v[i]=acc[i];
	fwrite(v, sizeof(float), 3, f);
	for (int i=0;i<3;i++)v[i]=rot[i];
	fwrite(v, sizeof(float), 3, f);
}

void Entity::loadFromFile(FILE *f)
{
	float v[3];
	fread(v, sizeof(float), 3, f);
	for (int i=0;i<3;i++)pos[i]=v[i];
	fread(v, sizeof(float), 3, f);
	for (int i=0;i<3;i++)vel[i]=v[i];
	fread(v, sizeof(float), 3, f);
	for (int i=0;i<3;i++)acc[i]=v[i];
	fread(v, sizeof(float), 3, f);
	for (int i=0;i<3;i++)rot[i]=v[i];
}
