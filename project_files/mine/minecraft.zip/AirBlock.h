#ifndef AIRBLOCK_H
#define AIRBLOCK_H

#include "common.h"
#include "Block.h"

class AirBlock : public Block {
	public:

	AirBlock(int id):Block(id){}
};

#endif
