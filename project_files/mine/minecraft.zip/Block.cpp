#include "Block.h"
#include <SFML/OpenGL.hpp>
#include "World.h"
#include "GrassBlock.h"
#include "BarkBlock.h"
#include "BillboardBlock.h"
#include "WaterBlock.h"
#include "TransparentBlock.h"
#include "LeavesTransparentBlock.h"

const float Block::dtex = 1/16.0;
Block *Block::blocks[256] = {0};
Block *Block::Air = new Block(0);
Block *Block::Stone = new Block(1);
Block *Block::Dirt = new Block(2);
Block *Block::Grass = new GrassBlock(3);
Block *Block::Wood = new Block(4);
Block *Block::Brick = new Block(7);
Block *Block::Rose = new BillboardBlock(12);
Block *Block::Flower = new BillboardBlock(13);
Block *Block::Water = new WaterBlock(14);
Block *Block::CobbleStone = new Block(16);
Block *Block::Sand = new Block(18);
Block *Block::Bark = new BarkBlock(20);
Block *Block::Iron = new Block(22);
Block *Block::Gold = new Block(23);
Block *Block::Diamond = new Block(24);
Block *Block::Obsidian = new Block(37);
Block *Block::Glass = new TransparentBlock(49);
Block *Block::LeavesTransparent = new LeavesTransparentBlock(52);
Block *Block::Leaves = new Block(53);

const BlockVData *tmp;
bool AOEn;
const float tmpD = 0.7;

Block::Block(const BlockData id):_id(id),_tex(id){
	Block::blocks[id] = this;
};

void Block::render(const float x, const float y, const float z) const
{
	if (!this->_id)
		return;

	AOEn = 0;
	renderFace(x, y, z, Top);
	renderFace(x, y, z, Bottom);
	renderFace(x, y, z, Left);
	renderFace(x, y, z, Right);
	renderFace(x, y, z, Front);
	renderFace(x, y, z, Back);
}

void Block::render(const int x, const int y, const int z, const BlockVData &vd) const
{
	if (!this->_id || !vd.visible)
		return;

	if (isOpaque()) {
		tmp = &vd;
		AOEn = 1;
	} else AOEn = 0;

	if (!vd.opaque[Top   ]) renderFace(x, y, z, Top);
	if (!vd.opaque[Bottom]) renderFace(x, y, z, Bottom);
	if (!vd.opaque[Right ]) renderFace(x, y, z, Right);
	if (!vd.opaque[Left  ]) renderFace(x, y, z, Left);
	if (!vd.opaque[Front ]) renderFace(x, y, z, Front);
	if (!vd.opaque[Back  ]) renderFace(x, y, z, Back);

	AOEn = 0;
}

void Block::renderFace(const float x, const float y, const float z, const Faces face) const
{
	const int tid = tex(face);
	const float tx = (tid % 16) / 16.0;
	const float ty = (tid / 16) / 16.0;
	const float u1[2] = {tx, ty+dtex};
	const float u2[2] = {tx+dtex, ty+dtex};
	const float u3[2] = {tx+dtex, ty};
	const float u4[2] = {tx, ty};
	const float s = 0.5;
	const float s2 = 1;

	glBegin(GL_QUADS);
	if (face == Front) {
		glNormal3f(0, 0, 1);
		glTexCoord2f(u1[0],u1[1]);glVertex3f(x-s, y, z+s);
		glTexCoord2f(u2[0],u2[1]);glVertex3f(x+s, y, z+s);
		glTexCoord2f(u3[0],u3[1]);glVertex3f(x+s, y+s2, z+s);
		glTexCoord2f(u4[0],u4[1]);glVertex3f(x-s, y+s2, z+s);
	}
	else if (face == Back) {
		glNormal3f(0, 0, -1);
		glTexCoord2f(u1[0],u1[1]);glVertex3f(x+s, y, z-s);
		glTexCoord2f(u2[0],u2[1]);glVertex3f(x-s, y, z-s);
		glTexCoord2f(u3[0],u3[1]);glVertex3f(x-s, y+s2, z-s);
		glTexCoord2f(u4[0],u4[1]);glVertex3f(x+s, y+s2, z-s);
	}
	else if (face == Top) {
		glNormal3f(0, 1, 0);
		if (AOEn) {
			if (tmp->topAmb[3] || tmp->topAmb[0] || tmp->topAmb[4]) glColor3f(tmpD, tmpD, tmpD); else glColor3f(1,1,1); glTexCoord2f(u1[0],u1[1]);glVertex3f(x-s, y+s2, z+s);
			if (tmp->topAmb[0] || tmp->topAmb[1] || tmp->topAmb[5]) glColor3f(tmpD, tmpD, tmpD); else glColor3f(1,1,1); glTexCoord2f(u2[0],u2[1]);glVertex3f(x+s, y+s2, z+s);
			if (tmp->topAmb[1] || tmp->topAmb[2] || tmp->topAmb[6]) glColor3f(tmpD, tmpD, tmpD); else glColor3f(1,1,1); glTexCoord2f(u3[0],u3[1]);glVertex3f(x+s, y+s2, z-s);
			if (tmp->topAmb[2] || tmp->topAmb[3] || tmp->topAmb[7]) glColor3f(tmpD, tmpD, tmpD); else glColor3f(1,1,1); glTexCoord2f(u4[0],u4[1]);glVertex3f(x-s, y+s2, z-s);
			glColor3f(1,1,1);
		} else {
			glTexCoord2f(u1[0],u1[1]);glVertex3f(x-s, y+s2, z+s);
			glTexCoord2f(u2[0],u2[1]);glVertex3f(x+s, y+s2, z+s);
			glTexCoord2f(u3[0],u3[1]);glVertex3f(x+s, y+s2, z-s);
			glTexCoord2f(u4[0],u4[1]);glVertex3f(x-s, y+s2, z-s);
		}
	}
	else if (face == Bottom) {
		glNormal3f(0, -1, 0);
		glTexCoord2f(u1[0],u1[1]);glVertex3f(x-s, y, z-s);
		glTexCoord2f(u2[0],u2[1]);glVertex3f(x+s, y, z-s);
		glTexCoord2f(u3[0],u3[1]);glVertex3f(x+s, y, z+s);
		glTexCoord2f(u4[0],u4[1]);glVertex3f(x-s, y, z+s);
	}
	else if (face == Left) {
		glNormal3f(-1, 0, 0);
		glTexCoord2f(u1[0],u1[1]);glVertex3f(x-s, y, z-s);
		glTexCoord2f(u2[0],u2[1]);glVertex3f(x-s, y, z+s);
		glTexCoord2f(u3[0],u3[1]);glVertex3f(x-s, y+s2, z+s);
		glTexCoord2f(u4[0],u4[1]);glVertex3f(x-s, y+s2, z-s);
	}
	else if (face == Right) {
		glNormal3f(1, 0, 0);
		glTexCoord2f(u1[0],u1[1]);glVertex3f(x+s, y, z+s);
		glTexCoord2f(u2[0],u2[1]);glVertex3f(x+s, y, z-s);
		glTexCoord2f(u3[0],u3[1]);glVertex3f(x+s, y+s2, z-s);
		glTexCoord2f(u4[0],u4[1]);glVertex3f(x+s, y+s2, z+s);
	}
	glEnd();
}

void Block::updateVisibility(const int x, const int y, const int z, BlockVData &vd) const
{
	vd.visible = 0;
	if (!_id) return;

	if (World::isOpaque(x  , y+1, z  )) { vd.opaque[Top   ] = 1; } else { vd.opaque[Top   ] = 0; vd.visible = 1; }
	if (World::isOpaque(x  , y-1, z  )) { vd.opaque[Bottom] = 1; } else { vd.opaque[Bottom] = 0; vd.visible = 1; }
	if (World::isOpaque(x+1, y  , z  )) { vd.opaque[Right ] = 1; } else { vd.opaque[Right ] = 0; vd.visible = 1; }
	if (World::isOpaque(x-1, y  , z  )) { vd.opaque[Left  ] = 1; } else { vd.opaque[Left  ] = 0; vd.visible = 1; }
	if (World::isOpaque(x  , y  , z+1)) { vd.opaque[Front ] = 1; } else { vd.opaque[Front ] = 0; vd.visible = 1; }
	if (World::isOpaque(x  , y  , z-1)) { vd.opaque[Back  ] = 1; } else { vd.opaque[Back  ] = 0; vd.visible = 1; }

	if (World::isOpaque(x  , y+1, z+1)) { vd.topAmb[0] = 1; } else { vd.topAmb[0] = 0; }
	if (World::isOpaque(x+1, y+1, z  )) { vd.topAmb[1] = 1; } else { vd.topAmb[1] = 0; }
	if (World::isOpaque(x  , y+1, z-1)) { vd.topAmb[2] = 1; } else { vd.topAmb[2] = 0; }
	if (World::isOpaque(x-1, y+1, z  )) { vd.topAmb[3] = 1; } else { vd.topAmb[3] = 0; }

	if (World::isOpaque(x-1, y+1, z+1)) { vd.topAmb[4] = 1; } else { vd.topAmb[4] = 0; }
	if (World::isOpaque(x+1, y+1, z+1)) { vd.topAmb[5] = 1; } else { vd.topAmb[5] = 0; }
	if (World::isOpaque(x+1, y+1, z-1)) { vd.topAmb[6] = 1; } else { vd.topAmb[6] = 0; }
	if (World::isOpaque(x-1, y+1, z-1)) { vd.topAmb[7] = 1; } else { vd.topAmb[7] = 0; }
}
