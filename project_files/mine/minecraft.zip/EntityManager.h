#ifndef ENTITYMANAGER_H
#define ENTITYMANAGER_H

#include "common.h"

struct EntityNode {
	Entity *e;
	EntityNode *next;
	EntityNode():e(0),next(0){}
	EntityNode(Entity *e):e(e),next(0){}
};

class EntityIter {
	EntityNode *node;
	public:
		EntityIter(EntityNode *n):node(n){};
		bool operator !=(const EntityIter &other) const
		{ return node != other.node; }
		Entity *operator *() const
		{ return node->e; };
		const EntityIter& operator ++()
		{ node = node->next; return *this; }
};

class EntityManager {
	EntityNode *first;
	EntityNode *last;

	public:
	EntityManager():first(0),last(0){};
	~EntityManager();
	void add(Entity *e);
	void remove(Entity *e);
	EntityIter begin() const { return EntityIter(first); }
	EntityIter end() const { return EntityIter(last); }
};

#endif
