#ifndef RAYCAST_H
#define RAYCAST_H

#include "common.h"

Vector_T<float, 3> raycast(Vector_T<float, 3> origin, Vector_T<float, 3> direction, float radius, int &face);
int signum(float x);
int signum(int x);
float intbound(float s, float ds);
float mod(float value, int modulus);

#endif
