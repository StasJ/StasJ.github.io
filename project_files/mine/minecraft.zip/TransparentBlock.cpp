#include "TransparentBlock.h"
#include "World.h"

void TransparentBlock::updateVisibility(const int x, const int y, const int z, BlockVData &vd) const
{
	vd.visible = 0;

	if (World::isOpaque(x  , y+1, z  ) || World::getBlock(x  , y+1, z  ) == _id) { vd.opaque[Top   ] = 1; } else { vd.opaque[Top   ] = 0; vd.visible = 1; }
	if (World::isOpaque(x  , y-1, z  ) || World::getBlock(x  , y-1, z  ) == _id) { vd.opaque[Bottom] = 1; } else { vd.opaque[Bottom] = 0; vd.visible = 1; }
	if (World::isOpaque(x+1, y  , z  ) || World::getBlock(x+1, y  , z  ) == _id) { vd.opaque[Right ] = 1; } else { vd.opaque[Right ] = 0; vd.visible = 1; }
	if (World::isOpaque(x-1, y  , z  ) || World::getBlock(x-1, y  , z  ) == _id) { vd.opaque[Left  ] = 1; } else { vd.opaque[Left  ] = 0; vd.visible = 1; }
	if (World::isOpaque(x  , y  , z+1) || World::getBlock(x  , y  , z+1) == _id) { vd.opaque[Front ] = 1; } else { vd.opaque[Front ] = 0; vd.visible = 1; }
	if (World::isOpaque(x  , y  , z-1) || World::getBlock(x  , y  , z-1) == _id) { vd.opaque[Back  ] = 1; } else { vd.opaque[Back  ] = 0; vd.visible = 1; }
}
