#include "Application.h"

int main()
{
	return Application::run();
}
