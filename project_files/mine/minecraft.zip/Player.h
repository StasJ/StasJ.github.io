#ifndef PLAYER_H
#define PLAYER_H

#include "common.h"
#include "Entity.h"

#define PLAYER_WALK_SPEED 4
#define EYE_HEIGHT 1.7
#define MOUSE_SENSITIVITY 15

class Player : public Entity {
	bool isOnSolid;
	
	public:
		Player();
		void update(float dt);
		void userInput(float dt);
		void render();
		Vec3 getDirectionVector();
};

#endif
