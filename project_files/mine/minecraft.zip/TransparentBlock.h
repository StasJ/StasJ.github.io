#ifndef TRANSPARENTBLOCK_H
#define TRANSPARENTBLOCK_H

#include "common.h"
#include "Block.h"

class TransparentBlock : public Block {
	public:

	TransparentBlock(int id):Block(id){}

	int tex(Faces face) const {
		return _id;
	}
	void updateVisibility(const int x, const int y, const int z, BlockVData &vd) const;

	bool isOpaque() const {return false;}
};

#endif
