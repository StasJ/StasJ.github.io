//
//  Matrix.h
//  Rasterize Testing
//
//  Created by Stas Jaroszynski on 8/11/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Rasterize_Testing__Matrix__
#define __Rasterize_Testing__Matrix__

#include "common.h"

class Matrix {
public:
	float m[4][4];
	
	Matrix();
	Matrix(const float m_[4][4]);
	Matrix(float m00, float m01, float m02, float m03,
		   float m10, float m11, float m12, float m13,
		   float m20, float m21, float m22, float m23,
		   float m30, float m31, float m32, float m33);
	
	Matrix  operator* (const Matrix &m2) const;
	Matrix &operator*=(const Matrix &m2);
	float  *operator[](int y) { return m[y]; }
	const float *operator[](int y) const { return m[y]; };
	
	float	Determinant() const;
	Matrix	Tanspose() const;
	Matrix	Inverse() const;
	Matrix	Clone() const;
	
	Vec4 ApplyTransform(const Vec4 &v) const;
	Vec3 ApplyTransform(const Vec3 &v) const;
	Vec2 ApplyTransform(const Vec2 &v) const;
	void   Print() const;
	
	static Matrix Identity();
	static Matrix Translate(float x, float y, float z);
	static Matrix RotateX(float rad);
	static Matrix RotateY(float rad);
	static Matrix RotateZ(float rad);
	static Matrix Scale(float s);
	static Matrix Perspective(float fov, float aspect, float zNear, float zFar);
	static Matrix Orthographic(float left, float right, float top, float bottom, float near, float far);
};

#endif /* defined(__Rasterize_Testing__Matrix__) */
