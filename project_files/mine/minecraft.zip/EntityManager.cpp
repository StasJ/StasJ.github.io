#include "EntityManager.h"

EntityManager::~EntityManager()
{
	EntityNode *ln;
	EntityNode *n = first;
	while (n) {
		//delete n->e;
		ln = n;
		n = n->next;
		delete ln;
	}
	first = 0;
	last = 0;
}

void EntityManager::add(Entity *e)
{
	EntityNode *n = new EntityNode(e);
	if (!first) {
		first = n;
		last = first;
	} else {
		last->next = n;
		last = n;
	}
}

void EntityManager::remove(Entity *e)
{
	EntityNode *n;
	EntityNode *ln;
	if (e == first->e) {
		if (first == last)
			last = 0;
		n = first;
		first = first->next;
		delete n;
	} else {
		n = first;
		while (n) {
			if (e == n->e) {
				ln->next = n->next;
				delete n;
				return;
			}
			ln = n;
			n = n->next;
		}
		Assert(0); // Not found
	}
}
