#include "BillboardBlock.h"

void BillboardBlock::render(const float x, const float y, const float z) const
{
	const int tid = _id;
	const float tx = (tid % 16) / 16.0;
	const float ty = (tid / 16) / 16.0;
	const float u1[2] = {tx, ty+dtex};
	const float u2[2] = {tx+dtex, ty+dtex};
	const float u3[2] = {tx+dtex, ty};
	const float u4[2] = {tx, ty};
	const float s = 0.5;
	const float s2 = 1;

	glBegin(GL_QUADS);
	glNormal3f(1, 0, 1);
	glTexCoord2f(u1[0],u1[1]);glVertex3f(x-s, y, z-s);
	glTexCoord2f(u2[0],u2[1]);glVertex3f(x+s, y, z+s);
	glTexCoord2f(u3[0],u3[1]);glVertex3f(x+s, y+s2, z+s);
	glTexCoord2f(u4[0],u4[1]);glVertex3f(x-s, y+s2, z-s);

	glNormal3f(-1, 0, -1);
	glTexCoord2f(u1[0],u1[1]);glVertex3f(x+s, y, z-s);
	glTexCoord2f(u2[0],u2[1]);glVertex3f(x-s, y, z+s);
	glTexCoord2f(u3[0],u3[1]);glVertex3f(x-s, y+s2, z+s);
	glTexCoord2f(u4[0],u4[1]);glVertex3f(x+s, y+s2, z-s);
	glEnd();
}

void BillboardBlock::render(const int x, const int y, const int z, const BlockVData &vd) const
{
	if (vd.visible)
		render(x, y, z);
}
