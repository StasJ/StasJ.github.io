#ifndef LEAVESTRANSPARENTBLOCK_H
#define LEAVESTRANSPARENTBLOCK_H

#include "common.h"
#include "Block.h"

class LeavesTransparentBlock : public Block {
	public:

	LeavesTransparentBlock(int id):Block(id){}

	int tex(Faces face) const {
		return _id;
	}
	void updateVisibility(const int x, const int y, const int z, BlockVData &vd) const;
	void render(const int x, const int y, const int z, const BlockVData &vd) const;

	bool isOpaque() const {return false;}
};

#endif
