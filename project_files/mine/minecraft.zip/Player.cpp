#include "Player.h"
#include "Application.h"
#include "World.h"
#include "Vector.h"
#include "Matrix.h"

Player::Player()
	:Entity(), isOnSolid(0)
{
}

void Player::update(float dt)
{ 
	pos.x += 0.5;
	pos.z += 0.5;
	bool wasSolid = World::isSolid((int)pos.x, (int)pos.y, (int)pos.z);
	Vec3 op = pos;
	vel.y -= dt * World::gravity;
	pos += vel * dt;
	bool isSolid = World::isSolid((int)pos.x, (int)pos.y, (int)pos.z);

	if (World::isSolid(pos.x, pos.y, pos.z)) {
		pos.y = (int)pos.y + 1;
		isOnSolid = 1;
	} else {
		isOnSolid = 0;
	}

	if (World::isSolid(pos.x, pos.y, pos.z) || World::isSolid(pos.x, pos.y+1, pos.z)) {
		if (pos.x < ((int)pos.x) + 0.2)
			pos.x = (int)pos.x - 0.03;
		if (pos.x > ((int)pos.x) + 0.8)
			pos.x = (int)pos.x + 1.03;
	}
	if (World::isSolid(pos.x, pos.y, pos.z) || World::isSolid(pos.x, pos.y+1, pos.z)) {
		if (pos.z < ((int)pos.z) + 0.2)
			pos.z = (int)pos.z - 0.03;
		if (pos.z > ((int)pos.z) + 0.8)
			pos.z = (int)pos.z + 1.03;
	}

	if (isOnSolid) {
		//printf("isOnSolid\n");
		vel.y = 0;
		vel.x *= 0.5;
		vel.z *= 0.5;
	} else ;

	if (pos.y < -10) {
		pos = Vec3(MW/2, MH, MD/2);
		vel = Vec3(0);
	}
	pos.x -= 0.5;
	pos.z -= 0.5;
}

void Player::userInput(float dt)
{
	float cos = cosf(rot.y*M_PI/180.0f);
	float sin = sinf(rot.y*M_PI/180.0f);
	float frict = isOnSolid ? 1 : 0.1;

	if (Keyboard::isKeyPressed(Keyboard::W)) {
		vel.z += PLAYER_WALK_SPEED * sin * frict;
		vel.x -= PLAYER_WALK_SPEED * cos * frict;
	}
	if (Keyboard::isKeyPressed(Keyboard::S)) {
		vel.z -= PLAYER_WALK_SPEED * sin * frict;
		vel.x += PLAYER_WALK_SPEED * cos * frict;
	}
	if (Keyboard::isKeyPressed(Keyboard::D)) {
		vel.z -= PLAYER_WALK_SPEED * cos * frict;
		vel.x -= PLAYER_WALK_SPEED * sin * frict;
	}
	if (Keyboard::isKeyPressed(Keyboard::A)) {
		vel.z += PLAYER_WALK_SPEED * cos * frict;
		vel.x += PLAYER_WALK_SPEED * sin * frict;
	}
	if (vel.x >  PLAYER_WALK_SPEED) vel.x = PLAYER_WALK_SPEED;
	if (vel.x < -PLAYER_WALK_SPEED) vel.x = -PLAYER_WALK_SPEED;
	if (vel.z > PLAYER_WALK_SPEED) vel.z = PLAYER_WALK_SPEED;
	if (vel.z < -PLAYER_WALK_SPEED) vel.z = -PLAYER_WALK_SPEED;
	if (Keyboard::isKeyPressed(Keyboard::Space)) {
		if (isOnSolid) {
			pos.y += 0.1;
			vel.y += 4.5;
		}
	}

	if (Application::hasFocus) {
		sf::Vector2u size = Application::window.getSize();
		sf::Vector2i mouse = sf::Mouse::getPosition(Application::window);
		rot.x -= MOUSE_SENSITIVITY * dt * (mouse.y - (int)size.y/2);
		rot.y -= MOUSE_SENSITIVITY * dt * (mouse.x - (int)size.x/2);
		rot.x = rot.x > 90 ? 90 : rot.x;
		rot.x = rot.x < -90 ? -90 : rot.x;
		sf::Mouse::setPosition(sf::Vector2i(size.x/2,size.y/2), Application::window);
	}
}

void Player::render()
{
}

Vec3 Player::getDirectionVector()
{
	Matrix m =  Matrix::RotateY(ToRadians(rot.y)) * Matrix::RotateZ(ToRadians(-rot.x));
	Vec3f d = Vec3f(-1, 0, 0);
	d = m.ApplyTransform(d);
	return d;
}
