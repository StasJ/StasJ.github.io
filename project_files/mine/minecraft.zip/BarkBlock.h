#ifndef BARKBLOCK_H
#define BARKBLOCK_H

#include "common.h"
#include "Block.h"

class BarkBlock : public Block {
	public:

	BarkBlock(const BlockData id):Block(id){}

	int tex(const Faces face) const {
		if (face == Top)
			return 21;
		if (face == Bottom)
			return 21;
		return 20;
	}
};

#endif
