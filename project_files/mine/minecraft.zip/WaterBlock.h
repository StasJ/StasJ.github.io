#ifndef WATERBLOCK_H
#define WATERBLOCK_H

#include "common.h"
#include "Block.h"

class WaterBlock : public Block {
	public:

	WaterBlock(int id):Block(id){}

	int tex(Faces face) const {
		return _id;
	}
	void updateVisibility(const int x, const int y, const int z, BlockVData &vd) const;
	void render(const int x, const int y, const int z, const BlockVData &vd) const;

	bool isSolid() const {return false;}
	bool isOpaque() const {return false;}
};

#endif
