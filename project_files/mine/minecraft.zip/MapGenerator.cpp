#include "MapGenerator.h"
#include "PerlinNoise.h"
#include "World.h"
#include "Block.h"

void MapGenerator::generateMap(int seed)
{

	printf("Generating Map [Seed %i]\n", seed);
	PerlinNoise p(seed);
	srand(seed);
	int waterLevel = 19;

	for (int i = 0; i < MH*MD*MW; i++)
		World::map[i] = 0;

	for (int z = 0; z < MD; z++) {
		for (int x = 0; x < MW; x++) {
			int h = p.noise(x/(float)MW*5, z/(float)MD*5, 1)*MH/4 + 15;
			for (int y = 0; y < h; y++) {
				if (y == h-1) {
					if (h < 21)
						World::setBlockNU(x,y,z,Block::Sand->id());
					else
						World::setBlockNU(x,y,z,Block::Grass->id());
				}
				else if (y >= h-4)
					World::setBlockNU(x,y,z,Block::Dirt->id());
				else
					World::setBlockNU(x,y,z,Block::Stone->id());

				if (World::getBlock(x, y, z) == Block::Grass->id()) {
					if (rand()/(float)RAND_MAX < 0.001)
						placeTree(x, y+1, z);
					else if (rand()/(float)RAND_MAX < 0.025)
						World::setBlockNU(x, y+1, z, Block::Rose->id());
					else if (rand()/(float)RAND_MAX < 0.025)
						World::setBlockNU(x, y+1, z, Block::Flower->id());
				}
			}
		}
	}
	for (int y = 0; y <= waterLevel; y++) {
		for (int z = 0; z < MD; z++) {
			for (int x = 0; x < MW; x++) {
				if (!World::getBlock(x,y,z))
					World::setBlockNU(x,y,z,Block::Water);
			}
		}
	}
}

void MapGenerator::placeTree(int x, int y, int z)
{
	float s = 4;
	int ey = y+5;
	for (;y<ey;y++)
		World::setBlockNU(x,y,z,Block::Bark->id());

	int cx = x;
	int cy = y;
	int cz = z;
	int ex = x+s+1;
	ey = y+s+1;
	int ez = z+s+1;
	int sx = x - (s+1);
	int sy = y - (s+1);
	int sz = z - (s+1);
	for (y = sy; y < ey; y++) {
		for (z = sz; z < ez; z++) {
			for (x = sx; x < ex; x++) {
				int dx = x-cx;
				int dy = y-cy;
				int dz = z-cz;
				//printf("[%i, %i, %i]\t[%i, %i, %i]\t[%i, %i, %i]\n", x, y, z, cx, cy, cz, ex, ey, ez);
				if (sqrtf(dx*dx + dy*dy + dz*dz) < s)
					World::setBlockNU(x, y, z, Block::LeavesTransparent->id());
			}
		}
	}
}
