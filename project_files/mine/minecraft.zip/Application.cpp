#include "Application.h"
#include "World.h"
#include "unistd.h"
#include "Button.h"

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

sf::Window Application::window;
bool Application::hasFocus = 1;

int Application::run()
{
	window.create(sf::VideoMode(800, 600), "OpenGL", sf::Style::Default, sf::ContextSettings(32));
	window.setVerticalSyncEnabled(false);
	window.setMouseCursorVisible(false);

	sf::Clock clock;
	sf::Font font;
	float tacc = 0;
	int frameacc = 0;
	printf("World size: %likB\n", (sizeof(World::map)+sizeof(World::vmap)+sizeof(World::lmap))>>10);

	World::init(10);
	if (access("./save/save1.dat", F_OK) != -1)
		World::loadFromFile("./save/save1.dat");

	bool running = true;
	window.display();
	sf::Mouse::setPosition(sf::Vector2i(window.getSize().x/2,window.getSize().y/2), window);
	while (running)
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
			{
				running = false;
			}
			else if (event.type == sf::Event::Resized)
			{
				glViewport(0, 0, event.size.width, event.size.height);
			}
			if (event.type == sf::Event::LostFocus)
				hasFocus = 0;
			if (event.type == sf::Event::GainedFocus)
				hasFocus = 1;
		}
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape)) {
			running = false;
			World::saveToFile("./save/save1.dat");
		}

		float dt = clock.restart().asSeconds();
		tacc += dt;frameacc++;
		if (tacc >= 1) {
			tacc -= 1;
			printf("FPS: %i\n", frameacc);
			frameacc = 0;
		}

		World::update(dt);

		glClearColor(135/255.f, 206/255.f, 250/255.f, 1);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		float fov = 55;
		float asp = window.getSize().x/(float)window.getSize().y;
		gluPerspective(fov, asp, 0.025, 100);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		// draw...
		World::render();

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		sf::Vector2<unsigned int> size = window.getSize();
		glOrtho(0, size.x, 0, size.y, -100, 100);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatef(size.x/2, size.y/2, 0);
		glEnable(GL_BLEND);
		glBlendFunc(GL_ONE_MINUS_DST_COLOR, GL_ZERO);
		glDisable(GL_DEPTH_TEST);
		int cw = 1;
		int ch = 5;
		for (int i = 0; i<2; i++) {
			glBegin(GL_QUADS);
			glVertex3f(-cw, -ch, 0);
			glVertex3f(cw, -ch, 0);
			glVertex3f(cw, ch, 0);
			glVertex3f(-cw, ch, 0);
			glEnd();
			glRotatef(90, 0, 0, 1);
		}
		glDisable(GL_BLEND);
		if (Block::blocks[World::placeBlockId]) {
			glEnable(GL_CULL_FACE);
			glEnable(GL_TEXTURE_2D);
			glLoadIdentity();
			glTranslatef(50, 35, 0);
			glScalef(60,60,60);
			glRotatef(45, 1, 0, 0);
			glRotatef(45, 0, 1, 0);
			Block::blocks[World::placeBlockId]->render(0,0,0);
			glDisable(GL_TEXTURE_2D);
			glDisable(GL_CULL_FACE);
		}

		window.display();
	}
	return 0;
}
