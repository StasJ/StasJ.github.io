#include "World.h"
#include <SFML/OpenGL.hpp>
#include "Vector.h"
#include "RayCast.h"
#include "Application.h"
#include "Matrix.h"
#include "MapGenerator.h"
#include <tuple>

const float World::gravity = 9.81;

BlockData World::map[MH * MD * MW] = {0};
BlockVData World::vmap[MH * MW * MD] = {0};
int World::lmap[MW * MD] = {0};
std::vector<TransparentQueueData> World::transparentQueue;
Player *World::player = 0;
EntityManager World::entities;
float World::dt = 0;
Vector3i World::selectedCoord;
bool World::isSelected = 0;
int World::selectedFace = 0;
int World::placeBlockId = 7;
bool World::leftDown = 0;
bool World::rightDown = 0;

sf::Texture texture;
sf::Shader shader;

inline int getI(int x, int y, int z)
{
	int i = y * MW * MD + z * MW + x;
	Assert(i >= 0);
	Assert(i < MW * MD * MH);
	return i;
}

void World::init(int seed)
{
	Assert(texture.loadFromFile("./assets/terrain.png"));
	Assert(shader.loadFromFile("./basic.vert", "./basic.frag"));
	if (player) delete player;
	player = new Player();
	player->pos = Vec3(MW/2, MH-30, MD/2);
	MapGenerator::generateMap(seed);

	for (int y = 0; y < MH; y++) {
		for (int z = 0; z < MD; z++) {
			for (int x = 0; x < MW; x++) {
				updateBlock(x, y, z);
			}
		}
	}
}

int periodKey = 0;
int commaKey = 0;

void World::update(float dt)
{
	World::dt = dt;
	player->userInput(dt);
	player->update(dt);

	handleInput();
}

void World::render()
{
	Vec3 eye = player->pos;
	Vec3i eyei = Vec3i(eye.x, eye.y, eye.z);
	eye.y += EYE_HEIGHT;
	glRotatef(-player->rot.x, 1, 0, 0);
	glRotatef(-player->rot.y-90, 0, 1, 0);
	glTranslatef(-eye.x, -eye.y, -eye.z);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	sf::Shader::bind(&shader);
	sf::Texture::bind(&texture);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	GLfloat light_position[] = { 100.0, 100.0, 100.0, 1.0 };
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	transparentQueue.clear();
	int i = 0;
	for (int y = 0; y < MH; y++) {
		for (int z = 0; z < MD; z++) {
			for (int x = 0; x < MW; x++) {
				if (!Block::blocks[map[i]]->isOpaque()) {
					if (vmap[i].visible) {
						Vec3i dc = Vec3i(x,y,z)-eyei;
						int d = dc.x*dc.x + dc.y*dc.y + dc.z*dc.z;
						transparentQueue.push_back(TransparentQueueData(x, y, z, i, d));
					}
				}else
					drawBlock(x, y, z, i);
				i++;
			}
		}
	}

	//for (int i = 0; i < 20; i++) printf("%i, ", transparentQueue[i][4]); printf("\n");
	std::sort(transparentQueue.begin(), transparentQueue.end());
	//for (int i = 0; i < 5; i++) printf("%i, ", transparentQueue[i][4]); printf("\n");
	glEnable(GL_BLEND);
	glDepthMask(GL_FALSE);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glDisable(GL_CULL_FACE);
	glColor4f(1,1,1,1);
	for (TransparentQueueData bi : transparentQueue) {
		Block::blocks[map[bi.w]]->render(bi.x, bi.y, bi.z, vmap[bi.w]);
	}
	glDisable(GL_BLEND);
	glDepthMask(GL_TRUE);
	glEnable(GL_CULL_FACE);

	sf::Shader::bind(0);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_LIGHTING);
	drawHighlightedSelect();

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);

}

void World::loadFromFile(const char *path)
{
	printf("Loading %s\n", path);
	FILE *f = fopen(path, "r");
	Assert(f);
	player->loadFromFile(f);
	fread(map, sizeof(map), 1, f);
	fclose(f);

	for (int y = 0; y < MH; y++) {
		for (int z = 0; z < MD; z++) {
			for (int x = 0; x < MW; x++) {
				updateBlock(x, y, z);
			}
		}
	}
}

void World::saveToFile(const char *path)
{
	printf("Saving %s\n", path);
	FILE *f = fopen(path, "w");
	Assert(f);
	player->saveToFile(f);
	fwrite(map, sizeof(map), 1, f);
	fclose(f);
}

void World::updateBlock(const int x, const int y, const int z)
{
	int i = getIndex(x, y, z);
	int li = z * MW + x;
	if (Block::blocks[map[i]]->id()) {
		Block::blocks[map[i]]->updateVisibility(x, y, z, vmap[i]);

		if (isOpaque(x, y, z) && lmap[li] < y)
			lmap[li] = y;
	} else {
		if (lmap[li] == y) {
			for (int y2 = y; y2 >= 0; y2--)
				if (isOpaque(x, y2, z)) { lmap[li] = y2; break; }
		}
	}
}

void World::updateBlockNeighbors(const int x, const int y, const int z)
{
	if (y != MH-1) updateBlock(x  , y+1, z  );
	if (y != 0)	   updateBlock(x  , y-1, z  );
	if (x != MW-1) updateBlock(x+1, y  , z  );
	if (x != 0)    updateBlock(x-1, y  , z  );
	if (z != MD-1) updateBlock(x  , y  , z+1);
	if (z != 0)    updateBlock(x  , y  , z-1);

	if (y != 0 && x != MW-1) updateBlock(x+1, y-1, z  );
	if (y != 0 && x != 0)	 updateBlock(x-1, y-1, z  );
	if (y != 0 && z != MD-1) updateBlock(x  , y-1, z+1);
	if (y != 0 && z != 0)	 updateBlock(x  , y-1, z-1);
	if (y != 0 && x != MW-1 && z != MD-1) updateBlock(x+1, y-1, z+1);
	if (y != 0 && x != MW-1 && z != 0)    updateBlock(x+1, y-1, z-1);
	if (y != 0 && x != 0 && z != MD-1)	  updateBlock(x-1, y-1, z+1);
	if (y != 0 && x != 0 && z != 0)		  updateBlock(x-1, y-1, z-1);
}

void World::drawBlock(const int x, const int y, const int z, const int i)
{
	Block::blocks[map[i]]->render(x, y, z, vmap[i]);
}

void World::drawHighlightedSelect()
{
	int x = selectedCoord.x;
	int y = selectedCoord.y;
	int z = selectedCoord.z;
	glPushMatrix();
	glTranslatef(x, y, z);

	glPolygonMode(GL_FRONT, GL_LINE);
	glLineWidth(2);
	glScalef(1.002, 1.002, 1.002);
	glColor4f(1, 1, 1, 1);
	Block::Stone->render(0,0,0);

	glPolygonMode(GL_FRONT, GL_FILL);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	glColor4f(1, 1, 1, 0.2);
	Block::Stone->renderFace(0,0,0, (Faces)selectedFace);
	glColor4f(1, 1, 1, 1);

	glDisable(GL_BLEND);
	glPopMatrix();
}

void World::handleInput()
{
	if (Keyboard::isKeyPressed(Keyboard::Period)) {
		int old = placeBlockId;
		if (!periodKey) {
			while (1) {
				placeBlockId++;
				if (placeBlockId > 100) {
					placeBlockId = old;
					break;
				}
				if (Block::blocks[placeBlockId])
					break;
			}
		}
		periodKey = 1;
	} else periodKey = 0;
	if (Keyboard::isKeyPressed(Keyboard::Comma)) {
		int old = placeBlockId;
		if (!commaKey) {
			while (1) {
				placeBlockId--;
				if (placeBlockId < 1) {
					placeBlockId = old;
					break;
				}
				if (Block::blocks[placeBlockId])
					break;
			}
		}
		commaKey = 1;
	} else commaKey = 0;

	Vec3f b = raycast(player->pos + Vec3(0.5, EYE_HEIGHT, 0.5), player->getDirectionVector(), 10, selectedFace);
	if (b.x >= 0) {
		isSelected = 1;
		selectedCoord = Vector3i(b.x, b.y, b.z);
	} else {
		isSelected = 0;
	}
	bool left = sf::Mouse::isButtonPressed(sf::Mouse::Left);
	bool right = sf::Mouse::isButtonPressed(sf::Mouse::Right);
	int sx = selectedCoord.x;
	int sy = selectedCoord.y;
	int sz = selectedCoord.z;
	if (left) {
		if (!leftDown) {
			setBlock(selectedCoord.x, selectedCoord.y, selectedCoord.z, Block::Air);
			updateBlock(selectedCoord.x, selectedCoord.y, selectedCoord.z);
		}
		leftDown = 1;
	}
	if (right) {
		if (!rightDown) {
			switch (selectedFace) {
				case Top:	setBlock(sx  , sy+1, sz  , placeBlockId); break;
				case Bottom:setBlock(sx  , sy-1, sz  , placeBlockId); break;
				case Left:	setBlock(sx-1, sy  , sz  , placeBlockId); break;
				case Right:	setBlock(sx+1, sy  , sz  , placeBlockId); break;
				case Front:	setBlock(sx  , sy  , sz+1, placeBlockId); break;
				case Back:	setBlock(sx  , sy  , sz-1, placeBlockId); break;
			}
		}
		rightDown = 1;
	}
	leftDown = left;
	rightDown = right;

	static int wasRPressed = 0;
	if (Keyboard::isKeyPressed(Keyboard::R)) {
		if (!wasRPressed) {
			time_t tnow;
			time(&tnow);
			init((int)tnow);
		}
		wasRPressed = 1;
	} else {
		wasRPressed = 0;
	}
}

BlockData World::getBlock(const int x, const int y, const int z)
{
	return map[getI(x, y, z)];
}

void World::setBlock(const int x, const int y, const int z, const BlockData id)
{
	//printf("SET [%i, %i, %i]\n", x, y, z);
	map[getI(x, y, z)] = id;
	updateBlock(x, y, z);
	updateBlockNeighbors(x, y, z);
}

void World::setBlock(const int x, const int y, const int z, const Block *block)
{
	setBlock(x, y, z, block->id());
}

void World::setBlockNU(const int x, const int y, const int z, const BlockData id)
{
	map[getI(x, y, z)] = id;
}

void World::setBlockNU(const int x, const int y, const int z, const Block *block)
{
	setBlockNU(x, y, z, block->id());
}

bool World::isOpaque(const int x, const int y, const int z)
{
	if (x < 0 || x >= MW || y < 0 || y >= MH || z < 0 || z >= MD)
		return true;
	int i = getI(x, y, z);
	if (map[i])
		return Block::blocks[map[i]]->isOpaque();
	return false;
}

bool World::isSolid(const int x, const int y, const int z)
{
	if (x < 0 || x >= MW || y < 0 || y >= MH || z < 0 || z >= MD)
		return false;
	int i = getI(x, y, z);
	if (map[i])
		return Block::blocks[map[i]]->isSolid();
	return false;
}

inline int World::getIndex(const int x, const int y, const int z)
{
	int i = y * MW * MD + z * MW + x;
	Assert(i >= 0);
	Assert(i < MW * MD * MH);
	return i;
}

