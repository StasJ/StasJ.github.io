#ifndef BLOCK_H
#define BLOCK_H

#include "common.h"

enum Faces {
	Top,
	Bottom,
	Right,
	Left,
	Front,
	Back
};

typedef byte BlockData;

struct BlockVData {
	byte visible;
	byte opaque[6];
	byte topAmb[8];
};

class Block {
	protected:

	static const float dtex;
	BlockData _id;
	int _tex;

	public:

	static Block *blocks[256];
	static Block *Air;
	static Block *Stone;
	static Block *Dirt;
	static Block *Grass;
	static Block *Wood;
	static Block *Brick;
	static Block *Rose;
	static Block *Flower;
	static Block *Water;
	static Block *CobbleStone;
	static Block *Sand;
	static Block *Bark;
	static Block *Iron;
	static Block *Gold;
	static Block *Diamond;
	static Block *Obsidian;
	static Block *Glass;
	static Block *LeavesTransparent;
	static Block *Leaves;

	Block(const BlockData id);
	//Block(int id, int tex):_id(id),_tex(tex){};

	virtual void render(const float x, const float y, const float z) const;
	virtual void render(const int x, const int y, const int z, const BlockVData &vd) const;
	void renderFace(const float x, const float y, const float z, const Faces face) const;
	virtual void updateVisibility(const int x, const int y, const int z, BlockVData &vd) const;

	int id() const {return _id;}
	virtual int tex(const Faces face) const {return _tex;}
	virtual bool isSolid() const {return true;}
	virtual bool isOpaque() const {return true;}
};

#endif
