#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <math.h>
#include <vector>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>

#define DEBUG

#ifdef DEBUG
#define Breakpoint() raise(SIGINT)
#define Assert0(x) if (x) {printf("[%i:%s] Assert Failed: %s\n", __LINE__, __FILE__, #x); exit(1);}
#define Assert1(x) Assert0(!(x))
#define Assert(x) Assert1(x)
#define UnimplementedError() {printf("Unimplemented Function: %s\n", __FUNCTION__); exit(1);}
#else
#define Breakpoint()
#define Assert0(x)
#define Assert1(x)
#define Assert(x)
#endif

typedef unsigned char byte;
using sf::Keyboard;
using sf::Vector2i;
using sf::Vector3i;

class Application;
class Scene;
class Player;
class Entity;
class EntityManager;
class EntityIter;
class EntityNode;
class World;
class Block;

template <typename T, std::size_t N> class Vector_T;
typedef Vector_T<float, 4>	Vec4;
typedef Vector_T<float, 3>	Vec3;
typedef Vector_T<float, 2>	Vec2;
typedef Vector_T<int, 2>	Point;
typedef Vector_T<int, 3>	Vec3i;
typedef Vector_T<int, 4>	Vec4i;
typedef Vector_T<int, 5>	Vec5i;
typedef Vec3 Vec3f;

#define ToRadians(x) ((x)*M_PI/180.f)


#endif
