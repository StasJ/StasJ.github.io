#include "WaterBlock.h"
#include "World.h"

void WaterBlock::render(const int x, const int y, const int z, const BlockVData &vd) const
{
	glPushMatrix();
	glTranslatef(x,y,z);
	glScalef(1, 0.85, 1);
	glColor4f(1, 1, 1, 0.5);
	Block::render(0, 0, 0, vd);
	glColor4f(1, 1, 1, 1);
	glPopMatrix();
}

void WaterBlock::updateVisibility(const int x, const int y, const int z, BlockVData &vd) const
{
	static int db = 0;
	if (Keyboard::isKeyPressed(Keyboard::B))
		db = 1;
	if (db)
		Breakpoint();
	vd.visible = 0;

	if (World::isOpaque(x  , y+1, z  ) || World::getBlock(x  , y+1, z  ) == _id) { vd.opaque[Top   ] = 1; } else { vd.opaque[Top   ] = 0; vd.visible = 1; }
	if (World::isOpaque(x  , y-1, z  ) || World::getBlock(x  , y-1, z  ) == _id) { vd.opaque[Bottom] = 1; } else { vd.opaque[Bottom] = 0; vd.visible = 1; }
	if (World::isOpaque(x+1, y  , z  ) || World::getBlock(x+1, y  , z  ) == _id) { vd.opaque[Right ] = 1; } else { vd.opaque[Right ] = 0; vd.visible = 1; }
	if (World::isOpaque(x-1, y  , z  ) || World::getBlock(x-1, y  , z  ) == _id) { vd.opaque[Left  ] = 1; } else { vd.opaque[Left  ] = 0; vd.visible = 1; }
	if (World::isOpaque(x  , y  , z+1) || World::getBlock(x  , y  , z+1) == _id) { vd.opaque[Front ] = 1; } else { vd.opaque[Front ] = 0; vd.visible = 1; }
	if (World::isOpaque(x  , y  , z-1) || World::getBlock(x  , y  , z-1) == _id) { vd.opaque[Back  ] = 1; } else { vd.opaque[Back  ] = 0; vd.visible = 1; }
}
