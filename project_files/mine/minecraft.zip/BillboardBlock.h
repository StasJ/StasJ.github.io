#ifndef BILLBOARDBLOCK_H
#define BILLBOARDBLOCK_H

#include "common.h"
#include "Block.h"

class BillboardBlock : public Block {
	public:

	BillboardBlock(const BlockData id):Block(id){}

	void render(const float x, const float y, const float z) const;
	void render(const int x, const int y, const int z, const BlockVData &vd) const;
	bool isOpaque() const {return false;}
	bool isSolid() const {return false;}
};

#endif
