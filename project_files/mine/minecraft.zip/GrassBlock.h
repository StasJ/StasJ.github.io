#ifndef GRASSBLOCK_H
#define GRASSBLOCK_H

#include "common.h"
#include "Block.h"

class GrassBlock : public Block {
	public:

	GrassBlock(const int id):Block(id){}

	int tex(const Faces face) const {
		if (face == Top)
			return 0;
		if (face == Bottom)
			return 2;
		return 3;
	}
};

#endif
