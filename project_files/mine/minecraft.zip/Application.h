#ifndef APPLICATION_H
#define APPLICATION_H

#include "common.h"

class Application {
	public:
		static sf::Window window;
		static sf::Clock clock;
		static bool hasFocus;

		static int run();
};

#endif
