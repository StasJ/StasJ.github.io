//
//  IWindowManager.cpp
//  Game
//
//  Created by Stas Jaroszynski on 8/17/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include "IWindowProvider.h"