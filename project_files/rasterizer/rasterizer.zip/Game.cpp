//
//  Game.cpp
//  Game
//
//  Created by Stas Jaroszynski on 8/14/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include "Game.h"
#include "EntityManager.h"
#include "SoftwareGraphicsProvider.h"
#include "EntityDataCache.h"
#include "GLUTWinowProvider.h"
#include "Matrix.h"
#include "Vector.h"
#include "Model.h"
#include "GameTimer.h"

EntityManager *				Game::entityManager = new EntityManager;
IGraphicsProvider *			Game::graphicsProvider = SoftwareGraphicsProvider::Instance();
IWindowProvider	*			Game::windowProvider = GLUTWindowProvider::Instance();
EntityDataCache<Texture> *	Game::textureCache = new EntityDataCache<Texture>;
EntityDataCache<Model> *	Game::modelCache = new EntityDataCache<Model>;
float						Game::deltaTime = 0;

EntityManager *				Game::GetEntities() { return entityManager; }
IGraphicsProvider *			Game::GetGraphics() { return graphicsProvider; }
IWindowProvider *			Game::GetWindow()	{ return windowProvider; }
EntityDataCache<Texture> *	Game::GetTextures() { return textureCache; }
EntityDataCache<Model> *	Game::GetModels()	{ return modelCache; }
int							Game::GetWidth()	{ return graphicsProvider->GetWidth(); }
int							Game::GetHeight()	{ return graphicsProvider->GetHeight(); }
float						Game::GetDeltaTime(){ return deltaTime; }

#include "ITest.h"
#include "ClipTest.h"
#include "BaseTest.h"
#include "RoomTest.h"

RoomTest test;

void Game::Init()
{
	GameTimer::SetFPS(0);
	graphicsProvider->Init(640, 360);
	test.Init();
	windowProvider->Init("Rasterizer", 640, 360);
}

static float rotX = 0, rotY = 0, rotZ = 0, z = -5, y = 0, x = 0;
void Game::ProcessInput()
{
	return;
	if (GetWindow()->IsPressed('1')) exit(0);
	if (GetWindow()->IsPressed('a')) rotY += M_PI * deltaTime;
	if (GetWindow()->IsPressed('d')) rotY -= M_PI * deltaTime;
	if (GetWindow()->IsPressed('w')) rotX += M_PI * deltaTime;
	if (GetWindow()->IsPressed('s')) rotX -= M_PI * deltaTime;
	if (GetWindow()->IsPressed('q')) rotZ += M_PI * deltaTime;
	if (GetWindow()->IsPressed('e')) rotZ -= M_PI * deltaTime;
	if (GetWindow()->IsPressed('z')) z += M_PI * deltaTime;
	if (GetWindow()->IsPressed('x')) z -= M_PI * deltaTime;
	if (GetWindow()->IsPressed(KEY_UP)) y += 4 * deltaTime;
	if (GetWindow()->IsPressed(KEY_DOWN)) y -= 4 * deltaTime;
	if (GetWindow()->IsPressed(KEY_RIGHT)) x += 4 * deltaTime;
	if (GetWindow()->IsPressed(KEY_LEFT)) x -= 4 * deltaTime;
}

void Game::Loop()
{
	deltaTime = GameTimer::Update();
	ProcessInput();
	
	GetGraphics()->Color1f(0);
	GetGraphics()->Clear();
	GetGraphics()->Color1f(1);
	
	test.Update();
	
#ifdef RASTER_STATS
	GetGraphics()->R_DrawString(0, GetHeight()-9, "FPS %0.2f\nTRI %i", GameTimer::fps, GetGraphics()->GetStats().triangles);
#endif
}
