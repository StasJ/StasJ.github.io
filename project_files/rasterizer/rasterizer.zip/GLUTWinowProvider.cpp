//
//  GLUTWinowManager.cpp
//  Game
//
//  Created by Stas Jaroszynski on 8/17/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include "GLUTWinowProvider.h"
#include "Game.h"
#include "IGraphicsProvider.h"

GLUTWindowProvider *GLUTWindowProvider::instance;
vec2_t GLUTWindowProvider::mousePosition;
int GLUTWindowProvider::width, GLUTWindowProvider::height;
uchar GLUTWindowProvider::keysDown[256];

GLUTWindowProvider *GLUTWindowProvider::Instance()
{
	if (!instance)
		instance = new GLUTWindowProvider();
	return instance;
}

void GLUTWindowProvider::Init(const char *name, int ww, int hh)
{
	Notice("GLUT::Init needs to be called last during initialization because GLUT takes over the main thread.");
	width = ww;
	height = hh;
	
	auto DisplayFunc = []() {
		Game::Loop();
		
		const vid_t vid = Game::GetGraphics()->GetColorBuffer();
		Assert(vid.width == width && vid.height == height);
		
		glDrawPixels(width, height, GL_RGBA, GL_UNSIGNED_BYTE, (uchar *)vid.buffer);
		glFlush();
		glutPostRedisplay();
	};
	auto ReshapeFunc = [](int w, int h) {

		width = w;
		height = h;
		Game::GetGraphics()->Resize(w, h);
	};
	auto KeyboardDownFunc = [](unsigned char key, int, int) {
		keysDown[key] = 1;
	};
	auto KeyboardUpFunc = [](unsigned char key, int, int) {
		keysDown[key] = 0;
	};
	auto SpecialDownFunc = [](int key, int, int) {
		static const uchar x = 1;
		switch (key) {
			case GLUT_KEY_LEFT:keysDown[KEY_LEFT] = x;break;
			case GLUT_KEY_RIGHT:keysDown[KEY_RIGHT] = x;break;
			case GLUT_KEY_UP:keysDown[KEY_UP] = x;break;
			case GLUT_KEY_DOWN:keysDown[KEY_DOWN] = x;break;
			case GLUT_KEY_F1:keysDown[KEY_F1] = x;break;
			case GLUT_KEY_F2:keysDown[KEY_F2] = x;break;
			case GLUT_KEY_F3:keysDown[KEY_F3] = x;break;
			case GLUT_KEY_F4:keysDown[KEY_F4] = x;break;
			case GLUT_KEY_F5:keysDown[KEY_F5] = x;break;
			case GLUT_KEY_F6:keysDown[KEY_F6] = x;break;
			case GLUT_KEY_F7:keysDown[KEY_F7] = x;break;
			case GLUT_KEY_F8:keysDown[KEY_F8] = x;break;
			case GLUT_KEY_F9:keysDown[KEY_F9] = x;break;
			case GLUT_KEY_F10:keysDown[KEY_F10] = x;break;
			case GLUT_KEY_F11:keysDown[KEY_F11] = x;break;
			case GLUT_KEY_F12:keysDown[KEY_F12] = x;break;
			default:
				Warning("Key %i not captured", key);
				break;
		}
	};
	auto SpecialUpFunc = [](int key, int, int) {
		static const uchar x = 0;
		switch (key) {
			case GLUT_KEY_LEFT:keysDown[KEY_LEFT] = x;break;
			case GLUT_KEY_RIGHT:keysDown[KEY_RIGHT] = x;break;
			case GLUT_KEY_UP:keysDown[KEY_UP] = x;break;
			case GLUT_KEY_DOWN:keysDown[KEY_DOWN] = x;break;
			case GLUT_KEY_F1:keysDown[KEY_F1] = x;break;
			case GLUT_KEY_F2:keysDown[KEY_F2] = x;break;
			case GLUT_KEY_F3:keysDown[KEY_F3] = x;break;
			case GLUT_KEY_F4:keysDown[KEY_F4] = x;break;
			case GLUT_KEY_F5:keysDown[KEY_F5] = x;break;
			case GLUT_KEY_F6:keysDown[KEY_F6] = x;break;
			case GLUT_KEY_F7:keysDown[KEY_F7] = x;break;
			case GLUT_KEY_F8:keysDown[KEY_F8] = x;break;
			case GLUT_KEY_F9:keysDown[KEY_F9] = x;break;
			case GLUT_KEY_F10:keysDown[KEY_F10] = x;break;
			case GLUT_KEY_F11:keysDown[KEY_F11] = x;break;
			case GLUT_KEY_F12:keysDown[KEY_F12] = x;break;
			default:
				Warning("Key %i not captured", key);
				break;
		}
	};
	auto MotionFunc = [](int x, int y) {
		mousePosition = {(float)min(max(0,x),width-1), height-(float)min(max(0,y),height-1)};
	};
	auto PassiveMotionFunc = [](int x, int y) {
		mousePosition = {(float)min(max(0,x),width-1), height-(float)min(max(0,y),height-1)};
	};
	
	int argc = 0;
	glutInit(&argc, NULL);
	glutInitDisplayMode(GLUT_SINGLE);
	glutInitWindowSize(width, height);
	glutCreateWindow(name);
	glutDisplayFunc(DisplayFunc);
	glutReshapeFunc(ReshapeFunc);
	glutKeyboardFunc(KeyboardDownFunc);
	glutKeyboardUpFunc(KeyboardUpFunc);
	glutSpecialFunc(SpecialDownFunc);
	glutSpecialUpFunc(SpecialUpFunc);
	glutMotionFunc(MotionFunc);
	glutPassiveMotionFunc(PassiveMotionFunc);
	
	glutMainLoop();
}

void GLUTWindowProvider::Resize(int w, int h)
{
	width = w;
	height = h;
}

bool GLUTWindowProvider::IsPressed(const uchar key) const
{
	return keysDown[key];
}

vec2_t GLUTWindowProvider::GetMouse() const
{
//	vec2_t mouse = {
//		max(0.f, min((float)width-1, mousePosition.x)),
//		max(0.f, min((float)height-1, mousePosition.y))
//	};
	return mousePosition;
}

