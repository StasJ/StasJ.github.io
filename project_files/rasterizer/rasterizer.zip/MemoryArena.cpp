//
//  MemoryArena.cpp
//  Game
//
//  Created by Stas Jaroszynski on 8/29/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include "MemoryArena.h"

MemoryArena::MemoryArena(size_t size)
{
	data = (uchar *)malloc(size);
	dataSize = size;
	dataPtr = 0;
	Assert(data);
}

MemoryArena::~MemoryArena()
{
	Assert(data);
	free(data);
}

void MemoryArena::Resize(size_t size)
{
	Assert(dataPtr <= size);
	data = (uchar *)realloc(data, size);
	Assert(data);
	dataSize = size;
}

void *MemoryArena::Alloc(size_t size)
{
	if (dataPtr + size > dataSize) {
		Resize(size + dataPtr);
	}
	uchar *ptr = data + dataPtr;
	dataPtr += size;
	return ptr;
}

void *MemoryArena::Calloc(size_t size)
{
	if (dataPtr + size > dataSize) {
		Resize(size + dataPtr);
	}
	uchar *ptr = data + dataPtr;
	dataPtr += size;
	memset(ptr, 0, size);
	return ptr;
}

void MemoryArena::Free()
{
	dataPtr = 0;
}