//
//  common.h
//  Game
//
//  Created by Stas Jaroszynski on 8/14/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef Game_common_h
#define Game_common_h

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <string>
#include <string.h>
#include <stdarg.h>

// Unix dependant
#include <unistd.h>

#include "preprocessor_options.h"
#include "error.h"
#include "math.h"

//using std::vector;
//using std::string;
using std::min;
using std::max;
using std::swap;

typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned int  uint;

class Matrix;
class Game;
class IEntity;
class IEntityData;
class Entity;
class EntityManager;
class IGraphicsProvider;
class IWindowProvider;
class Lexer;
class Font;
class Texture;
class Model;

template <typename T> class EntityDataCache;

template <typename T, std::size_t N> class Vector_T;
typedef Vector_T<float, 4>	Vec4;
typedef Vector_T<float, 3>	Vec3;
typedef Vector_T<float, 2>	Vec2;
typedef Vector_T<int, 2>	Point;

#ifndef NDEBUG
#define TOGGLE(test,x,cycle) static bool x ## _bounce = 0; if (test) { if (!x ## _bounce) { x = (x + 1) % cycle; x ## _bounce = 1; } } else { x ## _bounce = 0; }
#endif

#define RESOURCE_PATH "data/"
#define DefineTempPathFromName(name, path) \
char *path = (char *)alloca(strlen(name) + strlen(RESOURCE_PATH) + 1); \
memcpy(path, RESOURCE_PATH, strlen(RESOURCE_PATH)); \
memcpy(path+strlen(RESOURCE_PATH), name, strlen(name)); \
path[strlen(RESOURCE_PATH) + strlen(name)] = 0;

#endif
