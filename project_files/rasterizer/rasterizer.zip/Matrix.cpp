//
//  Matrix.cpp
//  Rasterize Testing
//
//  Created by Stas Jaroszynski on 8/11/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include "Matrix.h"
#include "Vector.h"

Matrix::Matrix()
{
	m[0][0] = m[1][1] = m[2][2] = m[3][3] = 1;
	m[0][1] = m[0][2] = m[0][3] =
	m[1][0] = m[1][2] = m[1][3] =
	m[2][0] = m[2][1] = m[2][3] =
	m[3][0] = m[3][1] = m[3][2] = 0;
}

Matrix::Matrix(const float m_[4][4])
{
	memcpy(m, m_, sizeof(float) * 16);
}

Matrix::Matrix(float m00, float m01, float m02, float m03,
			   float m10, float m11, float m12, float m13,
			   float m20, float m21, float m22, float m23,
			   float m30, float m31, float m32, float m33)
{
	m[0][0] = m00;m[0][1] = m01;m[0][2] = m02;m[0][3] = m03;
	m[1][0] = m10;m[1][1] = m11;m[1][2] = m12;m[1][3] = m13;
	m[2][0] = m20;m[2][1] = m21;m[2][2] = m22;m[2][3] = m23;
	m[3][0] = m30;m[3][1] = m31;m[3][2] = m32;m[3][3] = m33;
}

Matrix Matrix::operator*(const Matrix &m2) const
{
	Matrix r;
	for (int y = 0; y < 4; y++)
		for (int x = 0; x < 4; x++)
			r.m[y][x] = m[y][0] * m2.m[0][x] +
						m[y][1] * m2.m[1][x] +
						m[y][2] * m2.m[2][x] +
						m[y][3] * m2.m[3][x];
	return r;
}

Matrix &Matrix::operator*=(const Matrix &m2)
{
	Matrix r;
	for (int y = 0; y < 4; y++)
		for (int x = 0; x < 4; x++)
			r.m[y][x] = m[y][0] * m2.m[0][x] +
			m[y][1] * m2.m[1][x] +
			m[y][2] * m2.m[2][x] +
			m[y][3] * m2.m[3][x];
	memcpy(m, r.m, 16 * sizeof(float));
	return *this;
}

float Matrix::Determinant() const
{
	return
	m[3][0] * m[2][1] * m[1][2] * m[0][3] - m[2][0] * m[3][1] * m[1][2] * m[0][3] -
	m[3][0] * m[1][1] * m[2][2] * m[0][3] + m[1][0] * m[3][1] * m[2][2] * m[0][3] +
	m[2][0] * m[1][1] * m[3][2] * m[0][3] - m[1][0] * m[2][1] * m[3][2] * m[0][3] -
	m[3][0] * m[2][1] * m[0][2] * m[1][3] + m[2][0] * m[3][1] * m[0][2] * m[1][3] +
	m[3][0] * m[0][1] * m[2][2] * m[1][3] - m[0][0] * m[3][1] * m[2][2] * m[1][3] -
	m[2][0] * m[0][1] * m[3][2] * m[1][3] + m[0][0] * m[2][1] * m[3][2] * m[1][3] +
	m[3][0] * m[1][1] * m[0][2] * m[2][3] - m[1][0] * m[3][1] * m[0][2] * m[2][3] -
	m[3][0] * m[0][1] * m[1][2] * m[2][3] + m[0][0] * m[3][1] * m[1][2] * m[2][3] +
	m[1][0] * m[0][1] * m[3][2] * m[2][3] - m[0][0] * m[1][1] * m[3][2] * m[2][3] -
	m[2][0] * m[1][1] * m[0][2] * m[3][3] + m[1][0] * m[2][1] * m[0][2] * m[3][3] +
	m[2][0] * m[0][1] * m[1][2] * m[3][3] - m[0][0] * m[2][1] * m[1][2] * m[3][3] -
	m[1][0] * m[0][1] * m[2][2] * m[3][3] + m[0][0] * m[1][1] * m[2][2] * m[3][3];
}

Matrix Matrix::Tanspose() const
{
	return Matrix(
				  m[0][0], m[1][0], m[2][0], m[3][0],
				  m[0][1], m[1][1], m[2][1], m[3][1],
				  m[0][2], m[1][2], m[2][2], m[3][2],
				  m[0][3], m[1][3], m[2][3], m[3][3]
				  );
}

Matrix Matrix::Inverse() const
{
	FatalIncompleteImplementation();
}

Matrix Matrix::Clone() const
{
	Matrix ret;
	memcpy(ret.m, m, sizeof(float) * 16);
	return ret;
}

Vec4 Matrix::ApplyTransform(const Vec4 &v) const
{
	Vec4 ret;
	ret.x = v.d[0] * m[0][0] + v.d[1] * m[0][1] + v.d[2] * m[0][2] + v.d[3] * m[0][3];
	ret.y = v.d[0] * m[1][0] + v.d[1] * m[1][1] + v.d[2] * m[1][2] + v.d[3] * m[1][3];
	ret.z = v.d[0] * m[2][0] + v.d[1] * m[2][1] + v.d[2] * m[2][2] + v.d[3] * m[2][3];
	ret.w = v.d[0] * m[3][0] + v.d[1] * m[3][1] + v.d[2] * m[3][2] + v.d[3] * m[3][3];
	return ret;
}

Vec3 Matrix::ApplyTransform(const Vec3 &v) const
{
	Vec3 ret;
	ret.x = v.d[0] * m[0][0] + v.d[1] * m[0][1] + v.d[2] * m[0][2] + m[0][3];
	ret.y = v.d[0] * m[1][0] + v.d[1] * m[1][1] + v.d[2] * m[1][2] + m[1][3];
	ret.z = v.d[0] * m[2][0] + v.d[1] * m[2][1] + v.d[2] * m[2][2] + m[2][3];
	return ret;
}

Vec2 Matrix::ApplyTransform(const Vec2 &v) const
{
	Vec2 ret;
	ret.x = v.d[0] * m[0][0] + v.d[1] * m[0][1] + m[0][3];
	ret.y = v.d[0] * m[1][0] + v.d[1] * m[1][1] + m[1][3];
	return ret;
}

void Matrix::Print() const
{
	printf("----------- Matrix -----------\n");
	printf("[%0.3f, %0.3f, %0.3f, %0.3f]\n", m[0][0], m[0][1], m[0][2], m[0][3]);
	printf("[%0.3f, %0.3f, %0.3f, %0.3f]\n", m[1][0], m[1][1], m[1][2], m[1][3]);
	printf("[%0.3f, %0.3f, %0.3f, %0.3f]\n", m[2][0], m[2][1], m[2][2], m[2][3]);
	printf("[%0.3f, %0.3f, %0.3f, %0.3f]\n", m[3][0], m[3][1], m[3][2], m[3][3]);
}



Matrix Matrix::Identity()
{
	return Matrix(
				  1, 0, 0, 0,
				  0, 1, 0, 0,
				  0, 0, 1, 0,
				  0, 0, 0, 1);
}

Matrix Matrix::Translate(float x, float y, float z)
{
	return Matrix(
				  1,0,0,x,
				  0,1,0,y,
				  0,0,1,z,
				  0,0,0,1);
}

Matrix Matrix::RotateX(float rad)
{
	float s = sinf(rad);
	float c = cosf(rad);
	return Matrix(
				  1, 0, 0, 0,
				  0, c,-s, 0,
				  0, s, c, 0,
				  0, 0, 0, 1);
}

Matrix Matrix::RotateY(float rad)
{
	float s = sinf(rad);
	float c = cosf(rad);
	return Matrix(
				  c, 0, s, 0,
				  0, 1, 0, 0,
				 -s, 0, c, 0,
				  0, 0, 0, 1);
}

Matrix Matrix::RotateZ(float rad)
{
	float s = sinf(rad);
	float c = cosf(rad);
	return Matrix(
				  c,-s, 0, 0,
				  s, c, 0, 0,
				  0, 0, 1, 0,
				  0, 0, 0, 1);
}

Matrix Matrix::Scale(float s)
{
	return Matrix(
				  s, 0, 0, 0,
				  0, s, 0, 0,
				  0, 0, s, 0,
				  0, 0, 0, 1);
}

Matrix Matrix::Perspective(float fov, float a, float n, float f)
{
	float s = 1.f / tanf(ToRadians(fov) * 0.5f);
	return Matrix(
				  s/a,	0,			0,			 0,
					0,	s,			0,			 0,
					0,	0,	 -(f+n)/(f-n),-(2*f*n)/(f-n),
					0,	0,			-1,			 0);
}

Matrix Matrix::Orthographic(float l, float r, float t, float b, float n, float f)
{
	float mx = 2/(r-l);
	float ax = -(r+l)/(r-l);
	float my = 2/(t-b);
	float ay = -(t+b)/(t-b);
	float mz = -2/(f-n);
	float az = -(f+n)/(f-n);
	
	return Matrix(
				  mx,	0,	0,	ax,
				  0,	my,	0,	ay,
				  0,	0,	mz,	az,
				  0,	0,	0,	1
	);
}