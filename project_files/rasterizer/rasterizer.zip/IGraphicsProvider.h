//
//  IGraphicsProvider.h
//  Game
//
//  Created by Stas Jaroszynski on 8/16/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__IGraphicsProvider__
#define __Game__IGraphicsProvider__

#include "g_common.h"

#define G_DEPTH_TEST	1
#define G_LIGHTING		2

#define G_COLOR_BUFFER	1
#define G_DEPTH_BUFFER	2

#define G_WIREFRAME		1
#define G_FILL			2

#define G_POINT_LIGHT 1
#define G_DIRECTIONAL_LIGHT 2

class IGraphicsProvider
{
public:
	virtual bool Init(int width, int height) = 0;
	virtual bool Resize(int width, int height) = 0;
	
	virtual void Color3f(float r, float g, float b) = 0;
	virtual void Color1f(float brightness) = 0;
	virtual void SetProjection(Matrix m) = 0;
	virtual void SetTransform(Matrix m) = 0;
	virtual void SetMVP(Matrix m) = 0;
	//virtual void CalculateMVP() = 0;
	virtual void RenderMode(uint mode) = 0;
	virtual void Enable(uint mode) = 0;
	virtual void Disable(uint mode) = 0;
//	virtual void SetOutput(uchar *data, int width, int height) = 0;
	
	virtual Matrix PushTransform() = 0;
	virtual void   PopTransform() = 0;
	
	virtual void DrawModel(const Model *m) = 0;
	virtual void Clear() = 0;
	virtual void DrawString(float x, float y, const char *s, ...) = 0;
	
	virtual void R_Fill(int x, int y, int w, int h) = 0;
	virtual void R_Line(int x, int y, int x1, int y1) = 0;
	virtual void R_Dot(int x, int y) = 0;
	virtual void R_TexCopy(int x, int y, const Texture *t, int tx, int ty, int tw, int th) = 0;
	virtual void R_DrawString(int x, int y, const char *s, ...) = 0;
	
	virtual const  vid_t GetColorBuffer() const = 0;
	virtual void   SetColorBuffer() = 0;
	virtual int    GetWidth() const = 0;
	virtual int    GetHeight() const = 0;
	virtual Matrix GetTransform() const = 0;
	virtual void   SetLight0(Vec4 val, float ambient, int type) = 0;
	
#ifdef RASTER_STATS
	virtual rasterizerStatitics_t GetStats() const = 0;
#endif
};

#endif /* defined(__Game__IGraphicsProvider__) */
