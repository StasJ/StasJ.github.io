//
//  IEntityData.h
//  Game
//
//  Created by Stas Jaroszynski on 8/16/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__IEntityData__
#define __Game__IEntityData__

#include "IEntity.h"

class IEntityData : public IEntity {
public:
	virtual int GetSize() const = 0;
	template<typename T> friend class EntityCache;
	
protected:
	virtual bool LoadFromFile(const char *path) = 0;
};

#endif /* defined(__Game__IEntityData__) */
