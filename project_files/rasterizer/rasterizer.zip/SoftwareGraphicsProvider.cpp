//
//  SoftwareGraphicsProvider.cpp
//  Game
//
//  Created by Stas Jaroszynski on 8/16/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include "SoftwareGraphicsProvider.h"
#include "Matrix.h"
#include "Model.h"
#include "Vector.h"
#include "Font.h"
#include "Texture.h"
#include <thread>

#define CLIPPED_NONE	0
#define CLIPPED_LEFT	1
#define CLIPPED_RIGHT	2
#define CLIPPED_TOP		4
#define CLIPPED_BOTTOM	8
#define CLIPPED_NEAR	16
#define CLIPPED_FAR		32

/* 
 --- TODO ---
 - Interpolate or at least set other values in clipping
 */

SoftwareGraphicsProvider *SoftwareGraphicsProvider::instance;
SoftwareGraphicsProvider *SoftwareGraphicsProvider::Instance()
{
	if (!instance)
		instance = new SoftwareGraphicsProvider;
	return instance;
}

SoftwareGraphicsProvider::SoftwareGraphicsProvider()
:enableMask(0), renderModeMask(0), clearMask(0), zBuff(0), font(0)
{
	vid.buffer = 0;
	Light0Dir = Vec4(0, 1, 0.3).Normalize();
}

bool SoftwareGraphicsProvider::CreateVid(int width, int height)
{
	vid.width = width;
	vid.height = height;
	vid.dataSize = width * height * sizeof(pixel_t);
	if (vid.buffer) {
		delete [] vid.buffer;
		delete [] zBuff;
	}
	vid.buffer = (pixel_t *)new uchar[vid.dataSize];
	zBuff = new float[width * height];
	if (!vid.buffer || !zBuff)
		return false;
	
	return true;
}

bool SoftwareGraphicsProvider::Init(int width, int height)
{
	RenderMode(G_FILL | G_WIREFRAME);
	
	if (!CreateVid(width, height))
		return false;
	
	clearMask = G_COLOR_BUFFER | G_DEPTH_BUFFER;
	
	Notice("Software::R_Line incomplete implementation");
	Notice("Software::Draw (model, general) incomplete implementation");
	Notice("Software:: Undefined behavior when Z = 0, however this should not occur with clipping");
	
	return true;
}

bool SoftwareGraphicsProvider::Resize(int width, int height)
{
	return CreateVid(width, height);
}

void SoftwareGraphicsProvider::ApplyModelView()
{
	for (int i = 0; i < rd.vertNum; i++) {
		rd.vert[i] = transformMatrix.ApplyTransform(rd.vert[i]);
	}
	// Remove translates from normal transform
	Matrix tn = transformMatrix.Clone();
	tn[0][3] = 0;
	tn[1][3] = 0;
	tn[2][3] = 0;
	tn[3][3] = 1;
	for (int i = 0; i < rd.normNum; i++) {
		rd.norm[i] = tn.ApplyTransform(rd.norm[i]);
	}
}

void SoftwareGraphicsProvider::CullFaces()
{
	for (auto it = rd.faces.begin(); it != rd.faces.end();) {
		float test = (rd.vert[(*it).b.vertex]-rd.vert[(*it).a.vertex]).Cross(rd.vert[(*it).c.vertex]-rd.vert[(*it).a.vertex]).Dot(rd.vert[(*it).a.vertex].Normalize());
		if (test > 0)
			it = rd.faces.erase(it);
		else
			it++;
	}
}

void SoftwareGraphicsProvider::CalculateLighting()
{
	//WarningIncompleteImplementation();
	if (!(enableMask & G_LIGHTING))
		return;
	auto end = rd.faces.end();
	if (Light0Type == G_POINT_LIGHT) {
		Vec4 pos = Light0Pos;
		/*Vec4 p = projectionMatrix.ApplyTransform(pos);
		p /= p.w;
		float w2 = (vid.width - 1) / 2.f;
		float h2 = (vid.height - 1) / 2.f;
		p.x = p.x * w2 + w2;
		p.y = p.y * h2 + h2;
		R_Fill(p.x-2, p.y-2, 4, 4);*/
		if (rd.m->smoothShading) {
			for (auto it = rd.faces.begin(); it != end; it++) {
				// Fixes -ffast-math error
				volatile float al = Clamp((pos - rd.vert[(*it).a.vertex]).Normalize().Dot(rd.norm[(*it).a.normal]), Light0Ambient, 1);
				(*it).a.light = al;
				(*it).b.light = Clamp((pos - rd.vert[(*it).b.vertex]).Normalize().Dot(rd.norm[(*it).b.normal]), Light0Ambient, 1);
				(*it).c.light = Clamp((pos - rd.vert[(*it).c.vertex]).Normalize().Dot(rd.norm[(*it).c.normal]), Light0Ambient, 1);
			}
		} else {
			for (auto it = rd.faces.begin(); it != end; it++) {
				Vec3 norm = rd.norm[(*it).a.normal] + rd.norm[(*it).b.normal] + rd.norm[(*it).c.normal];
				norm /= 3.f;
				norm.Normalize();
				Vec4 center = rd.vert[(*it).a.vertex] + rd.vert[(*it).b.vertex] + rd.vert[(*it).c.vertex];
				center /= 3.f;
				float light = Clamp((pos - center).Normalize().Dot(norm), Light0Ambient, 1);
				(*it).a.light = light;
				(*it).b.light = light;
				(*it).c.light = light;
			}
		}
	} else {
		Vec3 dir = -Light0Dir;
		if (rd.m->smoothShading) {
			for (auto it = rd.faces.begin(); it != end; it++) {
				(*it).a.light = Clamp(dir.Dot(rd.norm[(*it).a.normal]), Light0Ambient, 1);
				(*it).b.light = Clamp(dir.Dot(rd.norm[(*it).b.normal]), Light0Ambient, 1);
				(*it).c.light = Clamp(dir.Dot(rd.norm[(*it).c.normal]), Light0Ambient, 1);
			}
		} else {
			for (auto it = rd.faces.begin(); it != end; it++) {
				Vec3 norm = rd.norm[(*it).a.normal] + rd.norm[(*it).b.normal] + rd.norm[(*it).c.normal];
				norm /= 3.f;
				norm.Normalize();
				float light = Clamp(dir.Dot(norm), Light0Ambient, 1);
				(*it).a.light = light;
				(*it).b.light = light;
				(*it).c.light = light;
			}
		}
	}
}

void SoftwareGraphicsProvider::ApplyProjection()
{
	for (int i = 0; i < rd.vertNum; i++) {
		Vec4 v = rd.vert[i];
		rd.vert[i] = projectionMatrix.ApplyTransform(v);
	}
}

typedef struct {
	Vec4 vertex;
	Vec2 uv;
	Vec3 normal;
	float light;
} vertex_t;

void SoftwareGraphicsProvider::ClipToProjection()
{
	for (int i = 0; i < rd.vertNum; i++) {
		if (rd.vert[i].x >  rd.vert[i].w) rd.clippedV[i] |= CLIPPED_RIGHT;
		if (rd.vert[i].x < -rd.vert[i].w) rd.clippedV[i] |= CLIPPED_LEFT;
		if (rd.vert[i].y >  rd.vert[i].w) rd.clippedV[i] |= CLIPPED_TOP;
		if (rd.vert[i].y < -rd.vert[i].w) rd.clippedV[i] |= CLIPPED_BOTTOM;
		if (rd.vert[i].z >  rd.vert[i].w) rd.clippedV[i] |= CLIPPED_FAR;
		if (rd.vert[i].z < -rd.vert[i].w) rd.clippedV[i] |= CLIPPED_NEAR;
	}
	auto end = rd.faces.end();
	for (auto it = rd.faces.begin(); it != end; it++) {
		if (!(rd.clippedV[(*it).a.vertex] | rd.clippedV[(*it).b.vertex] | rd.clippedV[(*it).c.vertex])) {
			continue;
		} else if (rd.clippedV[(*it).a.vertex] & rd.clippedV[(*it).b.vertex] & rd.clippedV[(*it).c.vertex]) {
			it = rd.faces.erase(it);
			it--;
		} else {
			float Vec4::*clipAxis[] = {
				&Vec4::z,
				&Vec4::x,
				&Vec4::y
			};
			
			std::vector<vertex_t> in;
			std::vector<vertex_t> out = {
				{rd.vert[(*it).a.vertex], rd.tex[(*it).a.uv], rd.norm[(*it).a.normal], (*it).a.light},
				{rd.vert[(*it).b.vertex], rd.tex[(*it).b.uv], rd.norm[(*it).b.normal], (*it).b.light},
				{rd.vert[(*it).c.vertex], rd.tex[(*it).c.uv], rd.norm[(*it).c.normal], (*it).c.light}
			};
			
			for (int ai = 0; ai < sizeof clipAxis / sizeof clipAxis[0]; ai++) {
				for (int dir = -1; dir < 2; dir += 2) {
					in = out;
					out.clear();
					for (int i = 0; i < in.size(); i++) {
						vertex_t avt = in[i];
						vertex_t bvt = in[(i+1)%in.size()];
						Vec4 a = avt.vertex;
						Vec4 b = bvt.vertex;
						Vec3 an = avt.normal;
						Vec3 bn = bvt.normal;
						Vec2 au = avt.uv;
						Vec2 bu = bvt.uv;
						float al = avt.light;
						float bl = bvt.light;
						
						if (a.*clipAxis[ai] * dir <= a.w)
							out.push_back(avt);
						
						if ((a.*clipAxis[ai] * dir <= a.w) != (b.*clipAxis[ai] * dir <= b.w)) {
							float ratio = (a.w - (a.*clipAxis[ai] * dir)) / ((a.w - (a.*clipAxis[ai] * dir)) + ((b.*clipAxis[ai] * dir) - b.w));
							a.x = a.x + ((b.x - a.x) * ratio);
							a.y = a.y + ((b.y - a.y) * ratio);
							a.z = a.z + ((b.z - a.z) * ratio);
							a.w = a.w + ((b.w - a.w) * ratio);
							
							//an.x = an.x + ((bn.x - an.x) * ratio);
							//an.y = an.y + ((bn.y - an.y) * ratio);
							//an.z = an.z + ((bn.z - an.z) * ratio);
							
							au.x = au.x + ((bu.x - au.x) * ratio);
							au.y = au.y + ((bu.y - au.y) * ratio);
							
							al = al + ((bl - al) * ratio);

							avt.vertex = a;
							avt.normal = an;
							avt.uv = au;
							avt.light = al;
							out.push_back(avt);
						}
					}
				}
			}
			
			int vertStart = rd.vertNum;
			int uvStart = rd.texNum;
			int normStart = rd.normNum;
			int lightStart = 0;
			float lightTemp[32];
			for (int i = 0; i < out.size(); i++) {
				rd.vert[rd.vertNum++] = out[i].vertex;
				rd.norm[rd.normNum++] = out[i].normal;
				rd.tex[rd.texNum++] = out[i].uv;
				lightTemp[lightStart++] = out[i].light;
			}
			
			for (int i = 0; i < rd.vertNum-2-vertStart; i++) {
				vertexIndex_t ia;
				vertexIndex_t ib;
				vertexIndex_t ic;
				
				ia.vertex = vertStart;
				ib.vertex = vertStart + i + 1;
				ic.vertex = vertStart + i + 2;
				
				ia.normal = normStart;
				ib.normal = normStart + i + 1;
				ic.normal = normStart + i + 2;
				
				ia.uv = uvStart;
				ib.uv = uvStart + i + 1;
				ic.uv = uvStart + i + 2;
				
				ia.light = lightTemp[0];
				ib.light = lightTemp[i + 1];
				ic.light = lightTemp[i + 2];
				
				rd.faces.push_front({ia, ib, ic, (*it).material});
			}
			it = rd.faces.erase(it);
			it--;
		}
	}
}

void SoftwareGraphicsProvider::DivideByW()
{
	for (int i = 0; i < rd.vertNum; i++) {
		//sprintf(rd.debugV+128*i, "(%0.2f, %0.2f)", rd.vert[i].z, rd.vert[i].w);
		rd.vert[i].x /= rd.vert[i].w;
		rd.vert[i].y /= rd.vert[i].w;
		rd.vert[i].z /= rd.vert[i].w;
	}
}
void SoftwareGraphicsProvider::ToScreenSpace()
{
	float w2 = (vid.width - 1) / 2.f;
	float h2 = (vid.height - 1) / 2.f;
	for (int i = 0; i < rd.vertNum; i++) {
		rd.vert[i].x = rd.vert[i].x * w2 + w2;
		rd.vert[i].y = rd.vert[i].y * h2 + h2;
	}
}

void SoftwareGraphicsProvider::RasterizeTriangles()
{
	uchar lastMtl = 255;
	for (auto it = ++rd.faces.begin(); it != rd.faces.end(); it++) {
		uchar mtl = (*it).material;
		if (lastMtl != mtl) {
			lastMtl = mtl;
			rd.texture = rd.m->materials[mtl].map_kd;
		}
		Triangle((*it).a, (*it).b, (*it).c);
		//Triangle(rd.vert[(*it).a.vertex], rd.vert[(*it).b.vertex], rd.vert[(*it).c.vertex]);
		//R_DrawString(rd.vert[(*it).a.vertex].x, rd.vert[(*it).a.vertex].y, "%0.1f,%0.1f", rd.tex[(*it).a.uv].x, rd.tex[(*it).a.uv].y);
		//R_DrawString(rd.vert[(*it).b.vertex].x, rd.vert[(*it).b.vertex].y, "%0.1f,%0.1f", rd.tex[(*it).b.uv].x, rd.tex[(*it).b.uv].y);
		//R_DrawString(rd.vert[(*it).c.vertex].x, rd.vert[(*it).c.vertex].y, "%0.1f,%0.1f", rd.tex[(*it).c.uv].x, rd.tex[(*it).c.uv].y);
		//R_DrawString(rd.vert[(*it).c.vertex].x, rd.vert[(*it).c.vertex].y, "%0.1f", rd.vert[(*it).c.vertex].y);
	}
}

void SoftwareGraphicsProvider::RasterizeWireframe()
{
	for (auto it = rd.faces.begin(); it != rd.faces.end(); it++) {
		R_Line(rd.vert[(*it).a.vertex].x, rd.vert[(*it).a.vertex].y, rd.vert[(*it).b.vertex].x, rd.vert[(*it).b.vertex].y);
		R_Line(rd.vert[(*it).b.vertex].x, rd.vert[(*it).b.vertex].y, rd.vert[(*it).c.vertex].x, rd.vert[(*it).c.vertex].y);
		R_Line(rd.vert[(*it).a.vertex].x, rd.vert[(*it).a.vertex].y, rd.vert[(*it).c.vertex].x, rd.vert[(*it).c.vertex].y);
	}
}

Matrix SoftwareGraphicsProvider::PushTransform()
{
	transformStack.push(transformMatrix);
	return transformMatrix;
}

void SoftwareGraphicsProvider::PopTransform()
{
	transformMatrix = transformStack.top();
	transformStack.pop();
}

void SoftwareGraphicsProvider::DrawModel(const Model *m)
{
	Assert(m->vertexCount <= MAX_VERTS);
	rd.m = m;
	rd.vertNum = m->vertexCount;
	rd.faceNum = m->faceCount;
	rd.normNum = m->normalCount;
	rd.texNum  = m->uvCount;
	
	memset(rd.clippedV, 0, rd.vertNum * sizeof(char));
	for (int i = 0; i < m->vertexCount; i++) rd.vert[i] = Vec4(m->vertices[i].x, m->vertices[i].y, m->vertices[i].z, 1);
	for (int i = 0; i < m->normalCount; i++) rd.norm[i] = Vec3(m->normals[i].x, m->normals[i].y, m->normals[i].z);
	for (int i = 0; i < m->uvCount; i++) rd.tex[i] = Vec2(m->uvCoords[i].x, m->uvCoords[i].y);
	for (int i = 0; i < m->faceCount; i++)   rd.faces.push_back(m->faces[i]);
	
	ApplyModelView();
	CullFaces();
	CalculateLighting();
	ApplyProjection();
	ClipToProjection();
	
	DivideByW();
	ToScreenSpace();
	
	rd.texture = m->materials[0].map_kd;
	
	if (renderModeMask & G_FILL)
		RasterizeTriangles();
	if (renderModeMask & G_WIREFRAME)
		RasterizeWireframe();
	
	//R_DrawString(rd.vert[0].x, rd.vert[0].y, "%0.2f", rd.vert[0].z);
	
#ifdef RASTER_STATS
	stats.triangles += rd.faces.size();
#endif
	rd.faces.clear();
}

void SoftwareGraphicsProvider::Clear()
{
	if (clearMask & G_COLOR_BUFFER) {
		const uint size = vid.width * vid.height;
		const pixel_t c = color.As_pixel_t();
		pixel_t *buffer = vid.buffer;
		for (int i = 0; i < size; i++) {
			*buffer++ = c;
		}
	}
	if (clearMask & G_DEPTH_BUFFER) {
		const uint size = vid.width * vid.height;
		for (int i = 0; i < size; i++) {
			zBuff[i] = 2;
		}
	}
	
#ifdef RASTER_STATS
	stats.triangles = 0;
	stats.vertices = 0;
#endif
}

void SoftwareGraphicsProvider::DrawString(float xs, float ys, const char *fmt, ...)
{
	WarningIncompleteImplementation();
	Vec4 v = transformMatrix.ApplyTransform(Vec4(xs, ys, 0, 1));
	v = projectionMatrix.ApplyTransform(v);
	v /= v.w;
	int w2 = vid.width / 2;
	int h2 = vid.height / 2;
	v.x = v.x * w2 + w2;
	v.y = v.y * h2 + h2;
	
	char text[256];
	va_list ap;
	va_start(ap, fmt);
	int len = vsnprintf(text, 256, fmt, ap);
	va_end(ap);
	if (len == 0)
		return;
	R_DrawString(v.x, v.y, "%s", text);
}

void SoftwareGraphicsProvider::R_DrawString(int xs, int ys, const char *fmt, ...)
{
	if (!font) {
		font = Font::CreateDefaultFont();
		if (!font)
			return;
	}
	
	char text[256];
	va_list ap;
	va_start(ap, fmt);
	int len = vsnprintf(text, 256, fmt, ap);
	va_end(ap);
	if (len == 0)
		return;
	if (len > 255)
		Warning("String \"%s\" overflowed DrawString buffer by %i", fmt, len - 256);
	
	const char *s = text;
	int x = xs, y = ys;
	while (*s != 0) {
		if (*s == '\n') {
			y -= font->charHeight;
			x = xs;
			s++;
			continue;
		}
		
		int tx = (*s % font->charPerRow) * font->charWidth;
		int ty = 120 - (*s / font->charPerRow) * font->charHeight;
		
		if (!(x < 0 || x + font->charWidth >= vid.width ||
			y < 0 || y + font->charHeight >= vid.height)) {
			R_TexCopy(x, y, font->texture, tx, ty, font->charWidth, font->charHeight);
		}
		
		s++;
		x += font->charWidth;
	}
}

void SoftwareGraphicsProvider::R_Fill(int x, int y, int w, int h)
{
	if (x >= vid.width || y >= vid.height) return;
	if (x < 0) { w += x; x = 0; }
	if (y < 0) { h += y; y = 0; }
	if (w <= 0 || h <= 0) return;
	
	pixel_t *buffer;
	const pixel_t c = color.As_pixel_t();
	h += y; w += x;
	for (; y < h; y++) {
		buffer = vid.buffer + (y * vid.width + x);
		for (int x1 = x; x1 < w; x1++) {
			*buffer++ = c;
		}
	}
}

void SoftwareGraphicsProvider::R_Line(int x0, int y0, int x1, int y1)
{
	int dx = abs(x1-x0), sx = x0<x1 ? 1 : -1;
	int dy = abs(y1-y0), sy = y0<y1 ? 1 : -1;
	int err = (dx>dy ? dx : -dy)/2, e2;
	
	pixel_t c = color.As_pixel_t();
	
	for(;;){
		if (x0 >= 0 && y0 >= 0 && x0 < vid.width && y0 < vid.height)
			vid.buffer[x0 + y0 * vid.width] = c;
		else {
			__Break();
		}
		
		if (x0==x1 && y0==y1) break;
		e2 = err;
		if (e2 >-dx) { err -= dy; x0 += sx; }
		if (e2 < dy) { err += dx; y0 += sy; }
	}
}

void SoftwareGraphicsProvider::R_TexCopy(int xs, int ys, const Texture *t, int tx, int ty, int tw, int th)
{
	for (int y = 0; y < th; y++) {
		for (int x = 0; x < tw; x++) {
			const uchar *texPixel = &t->data[((ty + y) * t->width + tx + x) * 3];
			pixel_t *buf = vid.buffer + (ys + y) * vid.width + (xs + x);
			buf->r = texPixel[0];
			buf->g = texPixel[1];
			buf->b = texPixel[2];
		}
	}
}

#define LineHalfspace(x1, y1, x2, y2, x, y) ((x2 - x1) * (y - y1) - (y2 - y1) * (x - x1))

void SoftwareGraphicsProvider::ScanLine(int y, vertexIndex_t va, vertexIndex_t vb, vertexIndex_t vc, vertexIndex_t vd)
{
	Vec4 ap = rd.vert[va.vertex];
	Vec4 bp = rd.vert[vb.vertex];
	Vec4 cp = rd.vert[vc.vertex];
	Vec4 dp = rd.vert[vd.vertex];
	
	float g1 = ap.y != bp.y ? (y - ap.y) / (bp.y - ap.y) : 1;
	float g2 = cp.y != dp.y ? (y - cp.y) / (dp.y - cp.y) : 1;
	
	int sx = (int)Lerp(ap.x, bp.x, g1);
	int ex = (int)Lerp(cp.x, dp.x, g2);
	
	float z1 = Lerp(ap.z, bp.z, g1);
	float z2 = Lerp(cp.z, dp.z, g2);
	
	float l1, l2;
	l1 = Lerp(va.light, vb.light, g1);
	l2 = Lerp(vc.light, vd.light, g2);
	if (enableMask & G_LIGHTING) {
	}

	float wInv1 = Lerp(1.f/ap.w, 1.f/bp.w, g1);
	float wInv2 = Lerp(1.f/cp.w, 1.f/dp.w, g2);
	
	Texture *t = rd.texture;
	float au = rd.tex[va.uv].x / ap.w;
	float bu = rd.tex[vb.uv].x / bp.w;
	float cu = rd.tex[vc.uv].x / cp.w;
	float du = rd.tex[vd.uv].x / dp.w;
	float av = rd.tex[va.uv].y / ap.w;
	float bv = rd.tex[vb.uv].y / bp.w;
	float cv = rd.tex[vc.uv].y / cp.w;
	float dv = rd.tex[vd.uv].y / dp.w;
	
	float su = Lerp(au, bu, g1);
	float eu = Lerp(cu, du, g2);
	float sv = Lerp(av, bv, g1);
	float ev = Lerp(cv, dv, g2);
	
	for (int x = sx; x < ex; x++) {
		float grad = (x - sx) / (float)(ex - sx);
		float z = Lerp(z1, z2, grad);
		float l = Lerp(l1, l2, grad);
		float wInv = Lerp(wInv1, wInv2, grad);
		
		int u = (int)(Lerp(su, eu, grad)/wInv * (float)(t->width-1)) % t->width;
		int v = (int)(Lerp(sv, ev, grad)/wInv * (float)(t->height-1)) % t->height;
		
		if (zBuff[y * vid.width + x] > z) {
			uchar *c = &t->data[(v*t->width + u)*3];
			uchar *b = (uchar *)&vid.buffer[x + y * vid.width];
			b[0] = c[0] * l;
			b[1] = c[1] * l;
			b[2] = c[2] * l;
			zBuff[y * vid.width + x] = z;
		}
	}
	
}

void SoftwareGraphicsProvider::Triangle(vertexIndex_t v1, vertexIndex_t v2, vertexIndex_t v3)
{
	Vec4 *v = rd.vert;
	{
		if (v[v1.vertex].y > v[v2.vertex].y) {
			vertexIndex_t temp = v1;
			v1 = v2;
			v2 = temp;
		}
		if (v[v1.vertex].y > v[v3.vertex].y) {
			vertexIndex_t temp = v1;
			v1 = v3;
			v3 = temp;
		}
		if (v[v2.vertex].y > v[v3.vertex].y) {
			vertexIndex_t temp = v2;
			v2 = v3;
			v3 = temp;
		}
	}
	
	Vec4 a = v[v1.vertex];
	Vec4 b = v[v2.vertex];
	Vec4 c = v[v3.vertex];
	
	float dab, dac;
	if (b.y - a.y > 0)
		dab = (b.x - a.x) / (b.y - a.y);
	else
		dab = 0;
	if (c.y - a.y > 0)
		dac = (c.x - a.x) / (c.y - a.y);
	else
		dac = 0;

	if (dab > dac) {
		for (int y = (int)a.y; y <= (int)c.y; y++) {
			if (y < b.y) {
				ScanLine(y, v1, v3, v1, v2);
			} else {
				if (a.y == b.y)
					ScanLine(y, v2, v3, v1, v3);
				else
					ScanLine(y, v1, v3, v2, v3);
			}
		}
	} else {
		for (int y = (int)a.y; y <= (int)c.y; y++) {
			if (y < b.y) {
				ScanLine(y, v1, v2, v1, v3);
			} else {
				if (a.y == b.y)
					ScanLine(y, v1, v3, v2, v3);
				else
					ScanLine(y, v2, v3, v1, v3);
			}
		}
	}
	
}

void SoftwareGraphicsProvider::R_Dot(int x, int y)
{
	vid.buffer[x + y * vid.width] = color.As_pixel_t();
}

void SoftwareGraphicsProvider::SetColorBuffer()
{
	Fatal("Unimplemented");
}

void SoftwareGraphicsProvider::CalculateMVP()
{
	mvp = projectionMatrix * transformMatrix;
}

void SoftwareGraphicsProvider::SetLight0(Vec4 val, float ambient, int type)
{
	Light0Type = type;
	Light0Ambient = ambient;
	if (type == G_DIRECTIONAL_LIGHT)
		Light0Dir = val.Normalize();
	else
		Light0Pos = transformMatrix.ApplyTransform(val);
}

void SoftwareGraphicsProvider::Color3f(float r, float g, float b) { color.r = r; color.g = g; color.b = b; }
void SoftwareGraphicsProvider::Color1f(float brightness) { color.r = color.g = color.b = brightness; }
void SoftwareGraphicsProvider::SetProjection(Matrix m) { projectionMatrix = m; /*CalculateMVP();*/ }
void SoftwareGraphicsProvider::SetTransform(Matrix m) { transformMatrix = m; /*CalculateMVP();*/ }
void SoftwareGraphicsProvider::SetMVP(Matrix m) { mvp = m; }
void SoftwareGraphicsProvider::RenderMode(uint mode) { renderModeMask = mode; }
void SoftwareGraphicsProvider::Enable(uint mode) { enableMask |= mode; }
void SoftwareGraphicsProvider::Disable(uint mode) { enableMask &= ~mode; }
int  SoftwareGraphicsProvider::GetWidth() const  { return vid.width; }
int  SoftwareGraphicsProvider::GetHeight() const { return vid.height; }
const vid_t SoftwareGraphicsProvider::GetColorBuffer() const { return vid; }
Matrix SoftwareGraphicsProvider::GetTransform() const { return transformMatrix; }

#ifdef RASTER_STATS
rasterizerStatitics_t SoftwareGraphicsProvider::GetStats() const { return stats; }
#endif
