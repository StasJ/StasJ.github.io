//
//  ClipTest.cpp
//  Game
//
//  Created by Stas Jaroszynski on 8/26/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include "ClipTest.h"
#include "Game.h"
#include "IWindowProvider.h"
#include "IGraphicsProvider.h"
#include "Matrix.h"
#include "EntityDataCache.h"
#include "Vector.h"

//static float rotX = 0, rotY = 0, rotZ = 0, z = -5, y = 0, x = 0;
//static void ProcessInput()
//{
//	const float deltaTime = Game::GetDeltaTime();
//	if (Game::GetWindow()->IsPressed('1')) exit(0);
//	if (Game::GetWindow()->IsPressed('a')) rotY += M_PI * deltaTime;
//	if (Game::GetWindow()->IsPressed('d')) rotY -= M_PI * deltaTime;
//	if (Game::GetWindow()->IsPressed('w')) rotX += M_PI * deltaTime;
//	if (Game::GetWindow()->IsPressed('s')) rotX -= M_PI * deltaTime;
//	if (Game::GetWindow()->IsPressed('q')) rotZ += M_PI * deltaTime;
//	if (Game::GetWindow()->IsPressed('e')) rotZ -= M_PI * deltaTime;
//	if (Game::GetWindow()->IsPressed('z')) z += M_PI * deltaTime;
//	if (Game::GetWindow()->IsPressed('x')) z -= M_PI * deltaTime;
//	if (Game::GetWindow()->IsPressed(KEY_UP)) y += 4 * deltaTime;
//	if (Game::GetWindow()->IsPressed(KEY_DOWN)) y -= 4 * deltaTime;
//	if (Game::GetWindow()->IsPressed(KEY_RIGHT)) x += 4 * deltaTime;
//	if (Game::GetWindow()->IsPressed(KEY_LEFT)) x -= 4 * deltaTime;
//}
//
//struct vec2 {
//	float x,y;
//	vec2():x(0),y(0){}
//	vec2(float x_,float y_):x(x_),y(y_){}
//	inline float Dot(vec2 &v) const { return x*v.x + y*v.y; };
//	inline vec2 Norm() const { float l=x*x+y*y;if(l!=0){l=sqrtf(1/l);}return vec2(x*l,y*l); };
//	inline vec2 operator+(const vec2 &v) const { return vec2(x+v.x,y+v.y); }
//	inline vec2 operator*(const float f) const { return vec2(x*f, y*f); }
//};
//
//struct plane {
//	vec2 n;
//	float d;
//	bool IsClipped(vec2 &v) const { return n.Dot(v) > d; }
//};

void ClipTest::Update()
{
//	ProcessInput();
//	Game::GetGraphics()->SetProjection(Matrix::Orthographic(9, Game::GetWidth(), Game::GetHeight(), 0, -10, 10));
//	
//	std::vector<vec2> poly;
//	poly.push_back(vec2(-1, 1));
//	poly.push_back(vec2(-1,-1));
//	poly.push_back(vec2( 1,-1));
//	
//	plane clip[] = {
//		{vec2(1,0),2},
//		{vec2(1,1).Norm(),1},
//		{vec2(0,1).Norm(),1},
//		{vec2(-1,0).Norm(),0},
//		{vec2(0,-1).Norm(),0.5}
//	};
//	
//	Matrix trans = Matrix::Translate(x, y, 0) * Matrix::RotateZ(rotZ);
//	for (int i = 0; i < poly.size(); i++) {
//		Vec4 v = trans.ApplyTransform(Vec4(poly[i].x, poly[i].y));
//		poly[i] = vec2(v.x, v.y);
//	}
//	
//	std::vector<vec2> in;
//	std::vector<vec2> out = poly;
//	vec2 curr;
//	vec2 next;
//	plane p;
//	for (int pi = 0; pi < sizeof(clip)/sizeof(plane); pi++) {
//		in = out;
//		out.clear();
//		p = clip[pi];
//		for (int i = 0; i < in.size(); i++) {
//			curr = in[i];
//			next = in[(i+1)%in.size()];
//			
//			float currD = p.n.Dot(curr);
//			float nextD = p.n.Dot(next);
//			
//			if (currD <= p.d)
//				out.push_back(curr);
//			
//			if ((nextD > p.d) != (currD > p.d)) {
//				float ratio = (p.d - currD) / (nextD - currD);
//				next.x = curr.x + (next.x - curr.x) * ratio;
//				next.y = curr.y + (next.y - curr.y) * ratio;
//				out.push_back(next);
//			}
//		}
//	}
//	
//	Game::GetGraphics()->SetTransform(Matrix::Translate(200, 200, 0) * Matrix::Scale(50));
//	
//	Game::GetGraphics()->Color3f(0, 0, 1);
//	for (int i = 0; i < sizeof(clip)/sizeof(plane); i++) {
//		vec2 a = clip[i].n * clip[i].d;
//		a = a + ((vec2(-clip[i].n.y, clip[i].n.x) * -1)*10);
//		vec2 b = clip[i].n * clip[i].d;
//		b = b + ((vec2(-clip[i].n.y, clip[i].n.x))*10);
//		Game::GetGraphics()->Line2f(a.x, a.y, b.x, b.y);
//	}
//	
//	Game::GetGraphics()->Color1f(1);
//	int size = (int)out.size() - 2;
//	for (int i = 0; i < size; i++) {
//		vec2 a = out[0];
//		vec2 b = out[(i+1)%out.size()];
//		vec2 c = out[(i+2)%out.size()];
//		Game::GetGraphics()->Line2f(a.x, a.y, b.x, b.y);
//		Game::GetGraphics()->Line2f(a.x, a.y, c.x, c.y);
//		Game::GetGraphics()->Line2f(c.x, c.y, b.x, b.y);
//		Game::GetGraphics()->DrawString(b.x, b.y, "%i", i+1);
//		Game::GetGraphics()->DrawString(c.x, c.y, "%i", i+2);
//	}
}

