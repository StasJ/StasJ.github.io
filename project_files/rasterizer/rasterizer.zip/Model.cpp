///
//  Model.cpp
//  Game
//
//  Created by Stas Jaroszynski on 8/16/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include <fstream>
#include "Model.h"
#include "Game.h"
#include "EntityDataCache.h"
#include "stringUtil.h"

Material::Material()
{
	ka = {0};
	kd = {0};
	ks = {0};
	d = 0;
	map_kd = 0;
}

Model::Model()
{
	vertexCount = 0;
	normalCount = 0;
	uvCount = 0;
	faceCount = 0;
	matCount = 0;

	vertices = 0;
	normals = 0;
	uvCoords = 0;
	faces = 0;
	materials = 0;

	boundingRadius = 0;
	smoothShading = 1;
	loaded = 0;
}

Model::~Model()
{
	if (vertices)	delete [] vertices;
	if (normals)	delete [] normals;
	if (uvCoords)	delete [] uvCoords;
	if (faces)		delete [] faces;
	if (materials)	delete [] materials;
}

int Model::GetSize() const
{
	FatalIncompleteImplementation();
	int size = 0;
	return size;
}

bool Model::LoadFromFile(const char *name)
{
	
	//DefineTempPathFromName(name, path);
	std::string pathStr(name);
	if (StrBeginsWith(name, "data/")) {
		strcpy(this->name, name + 5);
	} else {
		strcpy(this->name, name);
		pathStr = "data/" + pathStr;
	}
	const char *path = pathStr.c_str();
	
	std::ifstream f(path);
	if (!f) {
		Error("File \"%s\" not found", path);
		return 0;
	}
	strcpy(this->name, name);
	std::vector<vec3_t> v;
	std::vector<vec3_t> n;
	std::vector<vec2_t> uv;
	std::vector<vertexIndex_t> indx;
	std::vector<uchar> faceMtl;
	MtlLib mtlLib;
	uchar mtl = 0;
	
	std::string str;
	float x, y, z;
	ushort vi[3], ti[3], ni[3];
	while (std::getline(f, str)) {
		const char *line = str.c_str();
		if (line[0] == 'v' && line[1] == ' ') {
			sscanf(line, "v %f %f %f", &x, &y, &z);
			v.push_back(vec3_t{x, y, z});
		} else if (line[0] == 'v' && line[1] == 'n') {
			sscanf(line, "vn %f %f %f", &x, &y, &z);
			n.push_back(vec3_t{x, y, z});
		} else if (line[0] == 'v' && line[1] == 't') {
			sscanf(line, "vt %f %f", &x, &y);
			uv.push_back(vec2_t{x, y});
		} else if (line[0] == 'f' && line[1] == ' ') {
			if (sscanf(line, "f %hd/%hd/%hd %hd/%hd/%hd %hd/%hd/%hd",
					   &vi[0], &ti[0], &ni[0],
					   &vi[1], &ti[1], &ni[1],
					   &vi[2], &ti[2], &ni[2]) == 9) {
				indx.push_back(vertexIndex_t{vi[0], ti[0], ni[0]});
				indx.push_back(vertexIndex_t{vi[1], ti[1], ni[1]});
				indx.push_back(vertexIndex_t{vi[2], ti[2], ni[2]});
			} else if (sscanf(line, "f %hd//%hd %hd//%hd %hd//%hd",
						&vi[0], &ni[0],
						&vi[1], &ni[1],
						&vi[2], &ni[2]) == 6) {
				indx.push_back(vertexIndex_t{vi[0], 1, ni[0]});
				indx.push_back(vertexIndex_t{vi[1], 1, ni[1]});
				indx.push_back(vertexIndex_t{vi[2], 1, ni[2]});
			} else if (sscanf(line, "f %hd %hd %hd", &vi[0], &vi[1], &vi[2]) == 3) {
				indx.push_back(vertexIndex_t{vi[0], 1, 1});
				indx.push_back(vertexIndex_t{vi[1], 1, 1});
				indx.push_back(vertexIndex_t{vi[2], 1, 1});
			}
			faceMtl.push_back(mtl);
		} else if (line[0] == 's') {
			sscanf(line, "s %i", &smoothShading);
		} else if (StrBeginsWith(line, "usemtl")) {
			if (!mtlLib.loaded)
				Error("usemtl called before mtllib in %s", path);

			char matName[1024];
			sscanf(line, "usemtl %s", matName);
			int t = -1;
			for (int i = 0; i < mtlLib.mtls.size(); i++) {
				if (mtlLib.mtls[i].NameMatches(matName)) {
					t = i;
					break;
				}
			}
			if (t == -1 || t > 255) {
				Error("Invalid material \"%s\" referenced in %s", matName, name);
			}
			mtl = (uchar) t;
		} else if (StrBeginsWith(line, "mtllib")) {
			if (mtlLib.loaded)
				Error("Attemped to load multiple mtllib in %s", path);
			char tPath[1024];
			sscanf(line, "mtllib %s", tPath);
			std::string libPath = GetPathFromLocal(path, std::string(tPath));
			mtlLib.LoadFromFile(libPath.c_str());
		}
	}
	f.close();
	
	vertexCount = v.size();
	normalCount = n.size();
	uvCount = uv.size();
	faceCount = indx.size() / 3;
	matCount = mtlLib.mtls.size();
	
	if (matCount == 0)
		matCount = 1;

	vertices = new vec3_t[vertexCount];
	normals = new vec3_t[normalCount];
	uvCoords = new vec2_t[uvCount];
	faces = new face_t[faceCount];
	materials = new Material[matCount];
	
	for (int i = 0; i < vertexCount; i++)
		vertices[i] = v[i];
	for (int i = 0; i < normalCount; i++)
		normals[i] = n[i];
	for (int i = 0; i < uvCount; i++)
		uvCoords[i] = uv[i];
	for (int i = 0; i < indx.size(); i++) {
		// OBJ index starts at 1 instead of 0
		indx[i].vertex--;
		indx[i].normal--;
		indx[i].uv--;
	}
	for (int i = 0; i < faceCount; i++) {
		faces[i] = {indx[i*3], indx[i*3+1], indx[i*3+2], faceMtl[i]};
	}
	if (mtlLib.loaded)
		for (int i = 0; i < matCount; i++)
			materials[i] = mtlLib.mtls[i];
	
	CalculateBoundingRadius();
	loaded = 1;
	Log("Model loaded [%s][v:%i n:%i t:%i]", path, vertexCount, normalCount, uvCount);
	
	return true;
}

void Model::CalculateBoundingRadius()
{
	float max = 0;
	float d;
	for (int i = 0; i < vertexCount; i++) {
		d = vertices[i].x*vertices[i].x + vertices[i].y*vertices[i].y + vertices[i].z*vertices[i].z;
		if (d > max) max = d;
	}
	boundingRadius = sqrtf(max);
}

Model *Model::CreateFromOBJ(const char *name)
{
	Model *model = new Model;
	if (!model->LoadFromFile(name)) {
		delete model;
		model = NULL;
	}
	
	return model;
}

void Model::Print() const
{
	printf("Model [%s]\nVert[%i] (", name, vertexCount);
	for (int i = 0; i < vertexCount; i++)
		printf("[%0.1f, %0.1f, %0.1f]", vertices[i].x, vertices[i].y, vertices[i].z);
	printf(")\nNorm[%i] (", normalCount);
	for (int i = 0; i < normalCount; i++)
		printf("[%0.1f, %0.1f, %0.1f]", normals[i].x, normals[i].y, normals[i].z);
	printf(")\nTexCoord[%i] (", uvCount);
	for (int i = 0; i < uvCount; i++)
		printf("[%0.1f, %0.1f]", uvCoords[i].x, uvCoords[i].y);
	printf(")\nFace[%i] (", faceCount);
	WarningIncompleteImplementation();
	for (int i = 0; i < faceCount; i++) {
		printf("[[%i, %i, %i]", faces[i].a.vertex, faces[i].a.normal, faces[i].a.uv);
		printf("[%i, %i, %i]", faces[i].b.vertex, faces[i].b.normal, faces[i].b.uv);
		printf("[%i, %i, %i]] ", faces[i].c.vertex, faces[i].c.normal, faces[i].c.uv);
	}
	printf(")\n\n");
}

void Model::PrintStats() const
{
	printf("Model [%s](Vert[%i] Norm[%i] UV[%i] Indx[%i])\n", name, vertexCount, normalCount, uvCount, faceCount);
}

bool MtlLib::LoadFromFile(const char *path)
{
	std::ifstream f(path);
	if (!f) {
		Error("File \"%s\" not found", path);
		return 0;
	}

	Material m;
	bool m1Set = 0;
	std::string str;
	while (std::getline(f, str)) {
		const char *line = str.c_str();
		
		if (line[0] == '#') {
			continue;
		}
		else if (StrBeginsWith(line, "newmtl")) {
			if (m1Set) {
				mtls.push_back(m);
			}
			m = Material();
			sscanf(line, "newmtl %s", m.name);
			m1Set = 1;
		}
		else if (StrBeginsWith(line, "Ka")) {
			sscanf(line, "Ka %f %f %f", &m.ka.x, &m.ka.y, &m.ka.z);
		}
		else if (StrBeginsWith(line, "Kd")) {
			sscanf(line, "Kd %f %f %f", &m.kd.x, &m.kd.y, &m.kd.z);
		}
		else if (StrBeginsWith(line, "Ks")) {
			sscanf(line, "Ks %f %f %f", &m.ks.x, &m.ks.y, &m.ks.z);
		}
		else if (StrBeginsWith(line, "map_Kd")) {
			char tLocPath[1024];
			sscanf(line, "map_Kd %s", tLocPath);
			std::string tPath = GetPathFromLocal(path, tLocPath);
			m.map_kd = Game::GetTextures()->LoadEntityFromFile(tPath.c_str());
		}
	}
	mtls.push_back(m);
	loaded = 1;
	Log("LibMtl loaded [%s]", path);
	return 1;
}
