//
//  RoomTest.cpp
//  Game Engine
//
//  Created by Stas Jaroszynski on 12/5/15.
//  Copyright (c) 2015 Stas Jaroszynski. All rights reserved.
//

#include "RoomTest.h"
#include "Game.h"
#include "IWindowProvider.h"
#include "IGraphicsProvider.h"
#include "Matrix.h"
#include "Vector.h"
#include "EntityDataCache.h"
#include "Entity.h"
#include "EntityManager.h"
#include <fstream>

static Model *m;
static float rotX = 0, rotY = 0, rotZ = 0, z = 3, y = 1.4, x = 0, far = 15, movSpeed = 3;
static int renderMode = 0;
static void ProcessInput()
{
	const float dt = Game::GetDeltaTime();
	IWindowProvider *w = Game::GetWindow();
	
	if (w->IsPressed('w')) {
		x += sinf(rotY) * dt * movSpeed;
		z -= cosf(rotY) * dt * movSpeed;
	}
	if (w->IsPressed('s')) {
		x -= sinf(rotY) * dt * movSpeed;
		z += cosf(rotY) * dt * movSpeed;
	}
	if (w->IsPressed('d')) {
		z += sinf(rotY) * dt * movSpeed;
		x += cosf(rotY) * dt * movSpeed;
	}
	if (w->IsPressed('a')) {
		z -= sinf(rotY) * dt * movSpeed;
		x -= cosf(rotY) * dt * movSpeed;
	}
	if (w->IsPressed(KEY_RIGHT)) rotY += M_PI * dt;
	if (w->IsPressed(KEY_LEFT)) rotY -= M_PI * dt;
	if (w->IsPressed(KEY_UP)) rotX -= M_PI * dt * 0.7;
	if (w->IsPressed(KEY_DOWN)) rotX += M_PI * dt * 0.7;
	
	TOGGLE(Game::GetWindow()->IsPressed('r'), renderMode, 2);
	
	if (Game::GetWindow()->IsPressed('1')) {
		FILE *f = fopen("data/save.txt", "w");
		fprintf(f, "%f\n", rotX);
		fprintf(f, "%f\n", rotY);
		fprintf(f, "%f\n", rotZ);
		fprintf(f, "%f\n", z);
		fprintf(f, "%f\n", y);
		fprintf(f, "%f\n", x);
		fclose(f);
		exit(0);
	}
	
	return;
	if (Game::GetWindow()->IsPressed('1')) exit(0);
	if (Game::GetWindow()->IsPressed('a')) rotY += M_PI * dt;
	if (Game::GetWindow()->IsPressed('d')) rotY -= M_PI * dt;
	if (Game::GetWindow()->IsPressed('w')) rotX += M_PI * dt;
	if (Game::GetWindow()->IsPressed('s')) rotX -= M_PI * dt;
	if (Game::GetWindow()->IsPressed('q')) rotZ += M_PI * dt;
	if (Game::GetWindow()->IsPressed('e')) rotZ -= M_PI * dt;
	if (Game::GetWindow()->IsPressed('z')) z += M_PI * dt;
	if (Game::GetWindow()->IsPressed('x')) z -= M_PI * dt;
	if (Game::GetWindow()->IsPressed('c')) far += M_PI * dt;
	if (Game::GetWindow()->IsPressed('v')) far -= M_PI * dt;
	if (Game::GetWindow()->IsPressed(KEY_UP)) y += 4 * dt;
	if (Game::GetWindow()->IsPressed(KEY_DOWN)) y -= 4 * dt;
	if (Game::GetWindow()->IsPressed(KEY_RIGHT)) x += 4 * dt;
	if (Game::GetWindow()->IsPressed(KEY_LEFT)) x -= 4 * dt;
}

void RoomTest::Init()
{
	std::ifstream f("data/save.txt");
	std::string lineStr;
	if (f) {
		std::getline(f, lineStr); sscanf(lineStr.c_str(), "%f", &rotX);
		std::getline(f, lineStr); sscanf(lineStr.c_str(), "%f", &rotY);
		std::getline(f, lineStr); sscanf(lineStr.c_str(), "%f", &rotZ);
		std::getline(f, lineStr); sscanf(lineStr.c_str(), "%f", &z);
		std::getline(f, lineStr); sscanf(lineStr.c_str(), "%f", &y);
		std::getline(f, lineStr); sscanf(lineStr.c_str(), "%f", &x);
		f.close();
	}
	
	// Game::GetModels()->LoadEntityFromFile("cube.obj")->texture = Game::GetTextures()->LoadEntityFromFile("cube.bmp");
	// Game::GetModels()->LoadEntityFromFile("f16.obj")->texture = Game::GetTextures()->LoadEntityFromFile("f16.bmp");
	//Texture *t = Game::GetTextures()->LoadEntityFromFile("room/prop_wallPanel_D02_dff.bmp");
	Texture *t = Game::GetTextures()->LoadEntityFromFile("cube.bmp");
	Game::GetModels()->LoadEntityFromFile("quad.obj")->materials[0].map_kd = t;
	Game::GetGraphics()->Enable(G_LIGHTING);
	Game::GetGraphics()->SetLight0(Vec4(0, -1, 0, 0), 0.2, G_DIRECTIONAL_LIGHT);
	EntityDataCache<Model> *models = Game::GetModels();
	EntityManager *entities = Game::GetEntities();

	Entity *desk = new Entity("desk");
	desk->model = models->GetEntityByName("room/table.obj");
	entities->AddEntity(desk);
	
	Entity *lamp = new Entity("lamp");
	lamp->model = models->GetEntityByName("room/lamp.obj");
	lamp->pos = Vec3(0, 2.3, 0);
	entities->AddEntity(lamp);
	
	Entity *wallB = new Entity("wallB");
	wallB->model = models->GetEntityByName("room/wall1 flat.obj");
	wallB->pos = Vec3(-2, 0, 1.9);
	wallB->rot = Vec3(0, M_PI, 0);
	entities->AddEntity(wallB);
	
	Entity *wallB2 = new Entity("wallB2");
	wallB2->model = models->GetEntityByName("room/wall1 flat.obj");
	wallB2->pos = Vec3(-2, 0, -1.9);
	wallB2->rot = Vec3(0, M_PI, 0);
	entities->AddEntity(wallB2);
}

void RoomTest::Update()
{
	IGraphicsProvider *g = Game::GetGraphics();
	ProcessInput();
	g->RenderMode(renderMode == 0 ? G_FILL : renderMode == 1 ? G_WIREFRAME : G_FILL | G_WIREFRAME);
	
	Game::GetGraphics()->Enable(G_LIGHTING);
	
	g->SetProjection(Matrix::Perspective(66, Game::GetWidth()/(float)Game::GetHeight(), 0.1, far));
	g->SetTransform(Matrix::RotateX(rotX) * Matrix::RotateY(rotY) * Matrix::RotateZ(rotZ) * Matrix::Translate(-x, -y, -z));
	static float t = 0;
	t += Game::GetDeltaTime();
	if (t > M_PI * 2)
		t = 0;
	float lx = 0;
	float lz = 0;//sinf(t);
	g->SetLight0(Vec4(lx, 1.8, lz), 0.2, G_POINT_LIGHT);
	//g->PushTransform();
	//g->SetTransform(g->GetTransform()*Matrix::Translate(lx, 1.8, lz)*Matrix::Scale(0.1));
	//g->DrawModel(Game::GetModels()->GetEntityByName("room/table.obj"));
	//g->PopTransform();
	
	Game::GetEntities()->ForEach([g](IEntity *e){
		((Entity *)e)->Draw();
	});
}