//
//  File.h
//  Game
//
//  Created by Stas Jaroszynski on 9/1/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__File__
#define __Game__File__

#include <iostream>

#endif /* defined(__Game__File__) */
