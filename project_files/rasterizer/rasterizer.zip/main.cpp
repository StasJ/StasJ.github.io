//
//  main.cpp
//  Game
//
//  Created by Stas Jaroszynski on 8/12/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include "Game.h"

int main(void)
{
	Game::Init();
}