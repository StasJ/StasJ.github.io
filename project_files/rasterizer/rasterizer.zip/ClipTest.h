//
//  ClipTest.h
//  Game
//
//  Created by Stas Jaroszynski on 8/26/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__ClipTest__
#define __Game__ClipTest__

#include "common.h"
#include "ITest.h"

class ClipTest : public ITest {
public:
	void Update();
};

#endif /* defined(__Game__ClipTest__) */
