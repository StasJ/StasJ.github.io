//
//  Texture.cpp
//  Rasterize Testing
//
//  Created by Stas Jaroszynski on 8/10/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include "Texture.h"
#include "stringUtil.h"

Texture::Texture()
:data(NULL), dataSize(0), width(0), height(0) {}

Texture::Texture(const uint width_, const uint height_) {
	width = width_;
	height = height_;
	dataSize = width * height * 3;
	data = new uchar[dataSize];
}

Texture::Texture(const uint width_, const uint height_, uchar *data_) {
	width = width_;
	height = height_;
	data = data_;
	dataSize = width * height * 3;
}

Texture::~Texture()
{
	if (data)
		delete [] data;
}

int Texture::GetSize() const
{
	return sizeof(Texture) + sizeof(uchar) * dataSize;
}

bool Texture::LoadFromFile(const char *name)
{
	return LoadFromBMP(name);
}

bool Texture::LoadFromBMP(const char *name)
{
	Assert(name);
	//DefineTempPathFromName(name, path);
	std::string pathStr(name);
	if (StrBeginsWith(name, "data/")) {
		strcpy(this->name, name + 5);
	} else {
		strcpy(this->name, name);
		pathStr = "data/" + pathStr;
	}
	const char *path = pathStr.c_str();
	
	uchar header[54];
	uint imageDataBegin;
	
	FILE *file = fopen(path, "rb");
	if (!file) {
		Error("Image could not be opened:%s", path);
		return 0;
	}
	
	if (fread(header, 1, 54, file) != 54) {
		Error("Invalid BMP file:%s", path);
		return 0;
	}
	
	if (header[0] != 'B' || header[1] != 'M') {
		Error("Invalid BMP file:%s", path);
		return 0;
	}
	
	imageDataBegin = *(int*)&(header[0x0A]);
	dataSize = *(int*)&(header[0x22]);
	width = *(int*)&(header[0x12]);
	height = *(int*)&(header[0x16]);
	
	if (!dataSize) dataSize = width * height * 3;
	if (!imageDataBegin) imageDataBegin = 54;
	
	data = new uchar[dataSize];
	
	fseek(file, imageDataBegin, SEEK_SET);
	fread(data, 1, dataSize, file);
	fclose(file);
	
	// Switch from bgr to rgb
	for (unsigned int i = 0; i < dataSize; i += 3)
		std::swap(data[i], data[i + 2]);
	
	Log("Texture loaded [%s]", path);
	return true;
}

Texture *Texture::CreateFromBMP(const char *path)
{
	Texture *texture = new Texture();
	if (!texture->LoadFromBMP(path)) {
		delete texture;
		texture = NULL;
	}
	return texture;
}

