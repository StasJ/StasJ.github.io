//
//  Game.h
//  Game
//
//  Created by Stas Jaroszynski on 8/14/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__Game__
#define __Game__Game__

#include "common.h"

class Game {
	static EntityManager *entityManager;
	static IGraphicsProvider *graphicsProvider;
	static IWindowProvider *windowProvider;
	static EntityDataCache<Texture> *textureCache;
	static EntityDataCache<Model> *modelCache;
	static float deltaTime;
	
	static void ProcessInput();
	
public:
	static void Init();
	static void Loop();
	
	static EntityManager *GetEntities();
	static IGraphicsProvider *GetGraphics();
	static IWindowProvider *GetWindow();
	static EntityDataCache<Texture> *GetTextures();
	static EntityDataCache<Model> *GetModels();
	static int		GetWidth();
	static int		GetHeight();
	static float	GetDeltaTime();
};

#endif /* defined(__Game__Game__) */
