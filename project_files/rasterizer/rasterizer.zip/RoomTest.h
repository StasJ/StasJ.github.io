//
//  RoomTest.h
//  Game Engine
//
//  Created by Stas Jaroszynski on 12/5/15.
//  Copyright (c) 2015 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game_Engine__RoomTest__
#define __Game_Engine__RoomTest__

#include "common.h"
#include "ITest.h"

class RoomTest : public ITest {
public:
	void Init();
	void Update();
};

#endif /* defined(__Game_Engine__RoomTest__) */
