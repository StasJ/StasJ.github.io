//
//  Color.h
//  Game
//
//  Created by Stas Jaroszynski on 8/16/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__Color__
#define __Game__Color__

#include "common.h"

class Color {
public:
	float r, g, b;
	
	Color():r(0),g(0),b(0) {};
	 Color(float rr, float gg, float bb)
	:r(rr), g(gg), b(bb){}
	
	uint AsInt() const { return ((uint)(r * 255) << 24) + ((uint)(g * 255) << 16) + ((uint)(b * 255) << 8) + 255; }
	pixel_t As_pixel_t() const { return { (uchar)(r * 255), (uchar)(g * 255), (uchar)(b * 255), 255 }; }
};

#endif /* defined(__Game__Color__) */
