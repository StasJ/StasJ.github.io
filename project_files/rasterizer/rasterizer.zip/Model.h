//
//  Model.h
//  Game
//
//  Created by Stas Jaroszynski on 8/16/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__Model__
#define __Game__Model__

#include "g_common.h"
#include "IEntityData.h"

struct Material : IEntity {
	vec3_t ka;
	vec3_t kd;
	vec3_t ks;
	float d;
	Texture *map_kd;

	Material();
};

struct MtlLib {
	std::vector<Material> mtls;
	bool loaded;

	MtlLib():loaded(0){}
	bool LoadFromFile(const char *path);
};

class Model : public IEntityData {
public:

	vec3_t *vertices;
	ushort vertexCount;
	
	vec3_t *normals;
	ushort normalCount;
	
	vec2_t *uvCoords;
	ushort uvCount;

	face_t *faces;
	ushort faceCount;

	Material *materials;
	uchar matCount;

	float boundingRadius;
	int smoothShading;
	bool loaded;
	
	static Model *CreateFromOBJ(const char *file);
	int GetSize() const;
	~Model();
	void Print() const;
	void PrintStats() const;
	void CalculateBoundingRadius();
	
	template<typename T> friend class EntityDataCache;
private:
	Model();
	bool LoadFromFile(const char *path);
};

#endif /* defined(__Game__Model__) */
