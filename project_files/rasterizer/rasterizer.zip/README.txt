   Description
------------------
A basic software rasterizer.
Features:
- textures
- loading .obj and .mtl files
- bitmap fonts
- smooth and flat lighting
- 1 point or directional lights
- transformation stack (ie push and pop transformations)
- backface culling
The clipping routine currently has a corner case I have not been able to
figure out.

      Running
------------------
make
./run

     Controls
------------------
WASD: fps movement
Arrows: look around
R: toggle wireframe
1: Exit
