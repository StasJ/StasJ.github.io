//
//  MemoryArena.h
//  Game
//
//  Created by Stas Jaroszynski on 8/29/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__MemoryArena__
#define __Game__MemoryArena__

#include "common.h"

class MemoryArena {
	uchar *data;
	size_t dataSize;
	size_t dataPtr;
	
public:
	MemoryArena(size_t size);
	~MemoryArena();
	
	void  Resize(size_t size);
	void *Alloc(size_t size);
	void *Calloc(size_t size);
	void  Free();
	
	template <typename T>
	T *Alloc(size_t count) {
		size_t size = count * sizeof(T);
		if (dataPtr + size > dataSize) {
			Resize(size + dataPtr);
		}
		uchar *ptr = data + dataPtr;
		dataPtr += size;
		return (T *)ptr;
	}
	
	template <typename T>
	T *Calloc(size_t count) {
		size_t size = count * sizeof(T);
		if (dataPtr + size > dataSize) {
			Resize(size + dataPtr);
		}
		uchar *ptr = data + dataPtr;
		dataPtr += size;
		memset(ptr, 0, size);
		return (T *)ptr;
	}
};

#endif /* defined(__Game__MemoryArena__) */
