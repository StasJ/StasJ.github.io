//
//  GameTimer.h
//  Game
//
//  Created by Stas Jaroszynski on 8/22/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__GameTimer__
#define __Game__GameTimer__

#include "common.h"

class GameTimer {
	
	static float fpsTimeAcc;
	static int fpsFrameCount;
	
	static time_t lastTime;
	
	static float fps;
	static float deltaTime;
	static float fpsTargetDeltaTime;
	
	static float Update();
	static void SetFPS(int fps_);
	
	friend class Game;
};

#endif /* defined(__Game__GameTimer__) */
