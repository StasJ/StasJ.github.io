//
//  Entity.cpp
//  Game
//
//  Created by Stas Jaroszynski on 8/16/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include "Entity.h"
#include "Game.h"
#include "IGraphicsProvider.h"
#include "Matrix.h"

Entity::Entity()
: pos(0), rot(0), model(0), isVisible(1) {}

Entity::Entity(const char *name)
{
	Entity();
	strcpy(this->name, name);
}

void Entity::Draw()
{
	if (!model)
		return;
	
	IGraphicsProvider *g = Game::GetGraphics();
	Matrix t = g->PushTransform();
	t = t * Matrix::Translate(pos.x, pos.y, pos.z);
	t = t * Matrix::RotateX(rot.x) * Matrix::RotateY(rot.y) * Matrix::RotateZ(rot.z);
	g->SetTransform(t);
	
	g->DrawModel(model);
	
	g->PopTransform();
}