//
//  GameTimer.cpp
//  Game
//
//  Created by Stas Jaroszynski on 8/22/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include "GameTimer.h"
#include <sys/time.h>

float  GameTimer::fps = 0;
float  GameTimer::fpsTimeAcc = 0;
int	   GameTimer::fpsFrameCount = 0;
float  GameTimer::deltaTime = 0;
time_t GameTimer::lastTime = 0;
float GameTimer::fpsTargetDeltaTime = 0;

float GameTimer::Update()
{
	time_t currentTime;
	do {
		struct timeval time;
		gettimeofday(&time, NULL);
		currentTime = time.tv_sec * 1000 + time.tv_usec / 1000;
		deltaTime = (currentTime - lastTime) / 1000.f;
	} while (deltaTime < fpsTargetDeltaTime);
	lastTime = currentTime;
	fpsTimeAcc += deltaTime;
	if (fpsTimeAcc >= 1) {
		fps = fpsFrameCount / fpsTimeAcc;
		fpsTimeAcc = fpsTimeAcc - (int)fpsTimeAcc;
		fpsFrameCount = 0;
	}fpsFrameCount++;
	return deltaTime;
}

void GameTimer::SetFPS(int fps_)
{
	if (fps_)
		fpsTargetDeltaTime = 1 / (float)fps_;
	else
		fpsTargetDeltaTime = 0;
}