//
//  EntityManager.h
//  Game
//
//  Created by Stas Jaroszynski on 8/14/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__EntityManager__
#define __Game__EntityManager__

#include "common.h"
#include <functional>

class EntityManager {
	std::vector<IEntity *> entities;
	
public:
	~EntityManager();
	IEntity *GetEntityByName(const char *) const;
	void AddEntity(IEntity *e);
	void ForEach(std::function<void (IEntity *e)> func);
	void Clear();
};

#endif /* defined(__Game__EntityManager__) */
