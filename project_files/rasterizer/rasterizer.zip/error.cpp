//
//  error.cpp
//  Rasterize Testing
//
//  Created by Stas Jaroszynski on 8/10/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string>
#include "error.h"
#include "preprocessor_options.h"

void Log(const char *s, ...)
{
#ifndef QUIET
	printf("#Log: ");
	va_list ap;
	va_start(ap, s);
	vprintf(s, ap);
	va_end(ap);
	printf("\n");
#endif
}

void Notice(const char *s, ...)
{
#ifndef QUIET
#ifndef QUIET_NOTICE
	printf("#Notice: ");
	va_list ap;
	va_start(ap, s);
	vprintf(s, ap);
	va_end(ap);
	printf("\n");
#endif
#endif
}

void Warning(const char *s, ...)
{
	printf("#Warning: ");
	va_list ap;
	va_start(ap, s);
	vprintf(s, ap);
	va_end(ap);
	printf("\n");
}

void Error(const char *s, ...)
{
	printf("#Error: ");
	va_list ap;
	va_start(ap, s);
	vprintf(s, ap);
	va_end(ap);
	printf("\n");
#ifdef EXIT_ON_ERROR
	exit(EXIT_FAILURE);
#endif
}

void Fatal(const char *s, ...)
{
	printf("#Fatal: ");
	va_list ap;
	va_start(ap, s);
	vprintf(s, ap);
	va_end(ap);
	printf("\n");
	exit(EXIT_FAILURE);
}

const char *StringFormat(const char *fmt, ...)
{
    int size = 100;
	std::string str;
    va_list ap;
    while (1) {
        str.resize(size);
        va_start(ap, fmt);
        int n = vsnprintf((char *)str.c_str(), size, fmt, ap);
        va_end(ap);
        if (n > -1 && n < size) {
            str.resize(n);
            return str.c_str();
        }
        if (n > -1)
            size = n + 1;
        else
            size *= 2;
    }
    return str.c_str();
}

void __Break() {}
void __AssertBreakFunc() {
#ifdef BREAK_ON_ASSERT_FAIL
	__Break();
#endif
}