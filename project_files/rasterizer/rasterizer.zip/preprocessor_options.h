//
//  preprocessor_options.h
//  Game
//
//  Created by Stas Jaroszynski on 8/18/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef Game_preprocessor_options_h
#define Game_preprocessor_options_h

#define EXIT_ON_ERROR
//#define NDEBUG
//#define QUIET
#define QUIET_NOTICE
#define BREAK_ON_ASSERT_FAIL
#define RASTER_STATS

#endif
