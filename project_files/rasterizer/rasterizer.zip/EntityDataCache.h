//
//  EntityCache.h
//  Game
//
//  Created by Stas Jaroszynski on 8/16/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__EntityCache__
#define __Game__EntityCache__

#include "common.h"
#include "IEntityData.h"
#include "Texture.h"
#include "Model.h"
	
template <typename T>
class EntityDataCache {
	std::vector<IEntityData *> entities;
	
public:
	EntityDataCache();
	~EntityDataCache();
	
	void	 AddEntity(T *e);
	T*		 GetEntityByName(const char *name);
	const T* GetEntityByName(const char *name) const;
	T*		 LoadEntityFromFile(const char *path);
	bool	 HasEntityByName(const char *name) const;
	int		 GetCount() const;
	void	 Clear();
	
	T *operator[](const int i);
};

template <typename T>
EntityDataCache<T>::EntityDataCache()
{
	Notice("Entity names are not case sensitive");
}

template <typename T>
EntityDataCache<T>::~EntityDataCache()
{
	Clear();
}

template <typename T>
void EntityDataCache<T>::AddEntity(T *e)
{
	entities.push_back(e);
}

template <typename T>
T *EntityDataCache<T>::GetEntityByName(const char *name)
{
	for (typename std::vector<IEntityData *>::iterator it = entities.begin(); it != entities.end(); it++) {
		if ((*it)->NameMatches(name)) {
			return (T *)*it;
		}
	}
	return LoadEntityFromFile(name);
}

template <typename T>
const T *EntityDataCache<T>::GetEntityByName(const char *name) const
{
	for (std::vector<IEntityData *>::const_iterator it = entities.begin(); it != entities.end(); it++) {
		if ((*it)->NameMatches(name)) {
			return *it;
		}
	}
	return LoadEntityFromFile(name);
}

template <typename T>
bool EntityDataCache<T>::HasEntityByName(const char *name) const
{
	for (std::vector<IEntityData *>::const_iterator it = entities.begin(); it != entities.end(); it++) {
		if ((*it)->NameMatches(name)) {
			return true;
		}
	}
	return false;
}

template <typename T>
T *EntityDataCache<T>::LoadEntityFromFile(const char *name)
{
	Assert(!HasEntityByName(name));
	T *entity = new T;
	if (!entity->LoadFromFile(name)) {
		delete entity;
		entity = NULL;
		Error("Failed to load entity \"%s\"", name);
		return NULL;
	}
	entities.push_back(entity);
	return entity;
}

template <typename T>
int EntityDataCache<T>::GetCount() const
{
	return (int)entities.size();
}

template <typename T>
void EntityDataCache<T>::Clear()
{
	for (std::vector<IEntityData *>::iterator it = entities.begin(); it != entities.end(); it++) {
		delete (T *)*it;
	}
	entities.clear();
}

template <typename T>
T *EntityDataCache<T>::operator[](const int i)
{
	Assert(i >= 0 && i < entities.size());
	return entities[i];
}

#endif /* defined(__Game__EntityCache__) */
