//
//  BaseTest.h
//  Game
//
//  Created by Stas Jaroszynski on 8/26/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__BaseTest__
#define __Game__BaseTest__

#include "common.h"
#include "ITest.h"

class BaseTest : public ITest {
public:
	void Init();
	void Update();
};

#endif /* defined(__Game__BaseTest__) */
