//
//  ITest.h
//  Game
//
//  Created by Stas Jaroszynski on 8/26/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef Game_ITest_h
#define Game_ITest_h

class ITest {
public:
	void Init() {}
	virtual void Update() = 0;
};

#endif