//
//  Cube.h
//  Game
//
//  Created by Stas Jaroszynski on 8/16/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__Cube__
#define __Game__Cube__

#include "common.h"
#include "Entity.h"

class Cube : public Entity {
public:
	Cube();
	~Cube();
	void Update(float dt);
	void Render();
};

#endif /* defined(__Game__Cube__) */
