//
//  Texture.h
//  Rasterize Testing
//
//  Created by Stas Jaroszynski on 8/10/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Rasterize_Testing__Texture__
#define __Rasterize_Testing__Texture__

#include "common.h"
#include "IEntityData.h"

class Texture : public IEntityData {
public:
	uchar *	data;
	uint	width;
	uint	height;
	uint	dataSize;
	
	Texture(const uint width, const uint height);
	Texture(const uint width, const uint height, uchar *data);
	~Texture();
	int GetSize() const;
	
	static Texture *CreateFromBMP(const char *name);
	
	template<typename T> friend class EntityDataCache;
	
protected:
	Texture();
	bool LoadFromFile(const char *name);
	bool LoadFromBMP(const char *name);
};



#endif /* defined(__Rasterize_Testing__Texture__) */
