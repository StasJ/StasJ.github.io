//
//  stringUtil.h
//  Game Engine
//
//  Created by Stas Jaroszynski on 12/7/15.
//  Copyright (c) 2015 Stas Jaroszynski. All rights reserved.
//

#ifndef Game_Engine_stringUtil_h
#define Game_Engine_stringUtil_h

#include <string>

static bool StrBeginsWith(const char *str, const char *tst)
{
	size_t len = strlen(tst);
	for (int i = 0; i < len; i++)
		if (tst[i] != str[i])
			return 0;
	return 1;
}

static std::string GetPathFromLocal(std::string from, std::string local)
{
	if (local[0] == '/')
		return local;
	if (StrBeginsWith(local.c_str(), "./")) {
		local = local.substr(2, std::string::npos);
	}
	size_t slashI = from.find_last_of('/');
	if (slashI != from.length()) {
		from = from.substr(0, slashI + 1);
	}
	return from + local;
}

#endif
