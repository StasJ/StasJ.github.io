//
//  Utilities.h
//  Game
//
//  Created by Stas Jaroszynski on 8/17/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef Game_Utilities_h
#define Game_Utilities_h

void PrintDataHex(void *d, size_t s)
{
	uchar *p = (uchar *)d;
	printf("0x");
	for (int i = 0; i < s; i++) {
		printf("%02x",p[i]);
	}
	printf("\n");
}

#endif
