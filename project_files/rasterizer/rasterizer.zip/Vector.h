//
//  Vector.h
//  Game
//
//  Created by Stas Jaroszynski on 8/14/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__Vector__
#define __Game__Vector__

#include "common.h"
#include "g_common.h"

#ifndef __APPLE__
#include <typeinfo>
#endif


template <typename T, std::size_t N>
class Vector_T {
public:
	union {
		T d[N];
		struct {
			T x;
			T y;
			T z;
			T w;
		};
	};
	
	Vector_T() {for (int i = 0; i < N; i++)d[i] = 0;};
	Vector_T(T x) {for (int i = 0; i < N; i++)d[i] = x;Assert(!HasNaNs());}
	Vector_T(T x, T y) {
		static_assert(N >= 2, "Assert Failed: Invalid Vector size for args");
		d[0] = x; d[1] = y;
		for (int i = 2; i < N; i++)d[i] = 0;
		w = 1;
		Assert(!HasNaNs());
	}
	Vector_T(T x, T y, T z) {
		static_assert(N >= 3, "Assert Failed: Invalid Vector size for args");
		d[0] = x; d[1] = y; d[2] = z;
		for (int i = 3; i < N; i++)d[i] = 0;
		w = 1;
		Assert(!HasNaNs());
	}
	Vector_T(T x, T y, T z, T w) {
		static_assert(N >= 4, "Assert Failed: Invalid Vector size for args");
		d[0] = x; d[1] = y; d[2] = z; d[3] = w;
		for (int i = 4; i < N; i++)d[i] = 0;
		Assert(!HasNaNs());
	}
	template <typename T2, std::size_t N2>
	Vector_T(const Vector_T<T2, N2> &v) {
		Assert(typeid(T) == typeid(T2));
		const int min = N < N2 ? N : N2;
		for (int i = 0; i < min; i++)d[i] = v.d[i];
		for (int i = min; i < N2; i++)d[i] = 0;
		Assert(!HasNaNs());
	}
	
	
	inline Vector_T<T, N>	operator+	(const Vector_T<T, N> &v)	const	{Vector_T<T,N>ret;for(int i=0;i<N;i++){ret.d[i]=d[i]+v.d[i];}return ret;}
	inline Vector_T<T, N>	operator-	(const Vector_T<T, N> &v)	const	{Vector_T<T,N>ret;for(int i=0;i<N;i++){ret.d[i]=d[i]-v.d[i];}return ret;}
	inline Vector_T<T, N>	operator*	(const float f)				const	{Vector_T<T,N>ret;for(int i=0;i<N;i++){ret.d[i]=f;}return ret;}
	inline Vector_T<T, N>	operator/	(const float f)				const	{Assert(f!=0);const float invf=1.f/f;Vector_T<T,N>ret;for(int i=0;i<N;i++){ret.d[i]=invf;}return ret;}
	inline Vector_T<T, N>	operator-	()							const	{Vector_T<T,N>ret;for(int i=0;i<N;i++){ret.d[i]=-d[i];}return ret;}
	
	inline Vector_T<T, N> &operator+=	(const Vector_T<T, N> &v)			{for(int i=0;i<N;i++){d[i]=d[i]+v.d[i];}return *this;}
	inline Vector_T<T, N> &operator-=	(const Vector_T<T, N> &v)			{for(int i=0;i<N;i++){d[i]=d[i]-v.d[i];}return *this;}
	inline Vector_T<T, N> &operator*=	(const float f)						{for(int i=0;i<N;i++){d[i]=d[i]*f;}return *this;}
	inline Vector_T<T, N> &operator/=	(const float f)						{Assert(f!=0);const float invf=1.f/f;for(int i=0;i<N;i++){d[i]=d[i]*invf;}return *this;}
	
	inline T Length()						 const	{T ret=0;for(int i=0;i<N;i++){ret+=d[i]*d[i];}return sqrtf(ret);}
	inline T LengthSquared()				 const	{T ret=0;for(int i=0;i<N;i++){ret+=d[i]*d[i];}return ret;}
	inline T Dot	(const Vector_T<T, N> &v)const	{T ret=0;for(int i=0;i<N;i++){ret+=d[i]*v.d[i];}return ret;}
	inline Vector_T<T, 3> Cross	(const Vector_T<T, N> &v) const	{Assert(N == 3 || N == 4);return Vector_T<T,3>(y*v.z - z*v.y, z*v.x - x*v.z, x*v.y - y*v.x);}
	inline Vector_T<T, N> Normalize() const {Vector_T<T, N> ret;float l=LengthSquared();if(l!=0)l=1.f/sqrtf(l);for(int i=0;i<N;i++){ret.d[i]=d[i]*l;}return ret;}
	
	inline bool HasNaNs()				const	{for(int i=0;i<N;i++){if(isnan(d[i])){return true;}}return false;}
	
	void Print() {printf("Vector<%s, %lu>(%.2f",typeid(T).name(),N,(float)d[0]);for(int i=1;i<N;i++)printf(", %.2f",(float)d[i]);printf(")");};
	void Println() {Print();printf("\n");}
};

#endif /* defined(__Game__Vector__) */
