//
//  GLUTWinowManager.h
//  Game
//
//  Created by Stas Jaroszynski on 8/17/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__GLUTWinowManager__
#define __Game__GLUTWinowManager__

#include "g_common.h"
#include "IWindowProvider.h"

class GLUTWindowProvider : public IWindowProvider {
	static GLUTWindowProvider *instance;
	
	static vec2_t mousePosition;
	static int width, height;
	static uchar keysDown[256];
	
public:
	static GLUTWindowProvider *Instance();
	
	void Init(const char *name, int with, int height);
	bool IsPressed(const uchar key) const;
	vec2_t GetMouse() const;
	
protected:
	void Resize(int w, int h);
	GLUTWindowProvider(){};
};

#endif /* defined(__Game__GLUTWinowManager__) */
