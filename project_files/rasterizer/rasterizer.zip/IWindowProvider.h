//
//  IWindowManager.h
//  Game
//
//  Created by Stas Jaroszynski on 8/17/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__IWindowManager__
#define __Game__IWindowManager__

#include "g_common.h"

#define KEY_F1		128
#define KEY_F2		129
#define KEY_F3		130
#define KEY_F4		131
#define KEY_F5		132
#define KEY_F6		133
#define KEY_F7		134
#define KEY_F8		135
#define KEY_F9		136
#define KEY_F10		137
#define KEY_F11		138
#define KEY_F12		139
#define KEY_LEFT	140
#define KEY_UP		141
#define KEY_RIGHT	142
#define KEY_DOWN	143

class IWindowProvider {
public:
	virtual void Init(const char *name, int with, int height) = 0;
	virtual bool IsPressed(const uchar key) const = 0;
	virtual vec2_t GetMouse() const = 0;
	
protected:
	virtual void Resize(int w, int h) = 0;
	
private:
};

#endif /* defined(__Game__IWindowManager__) */
