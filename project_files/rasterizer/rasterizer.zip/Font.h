//
//  Font.h
//  Game
//
//  Created by Stas Jaroszynski on 8/18/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__Font__
#define __Game__Font__

#include "common.h"

class Font {
	Font(Texture *t, int cw, int ch, int cpr);
public:
	const Texture *texture;
	const int charWidth;
	const int charHeight;
	const int charPerRow;
	const uchar transparentColor[3];
	
	static Font *CreateFont(const char *file, int charWidth, int charHeight);
	static Font *CreateDefaultFont();
};

#endif /* defined(__Game__Font__) */
