//
//  Font.cpp
//  Game
//
//  Created by Stas Jaroszynski on 8/18/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include "Font.h"
#include "Game.h"
#include "EntityDataCache.h"
#include "Texture.h"

Font::Font(Texture *t, int cw, int ch, int cpr)
: texture(t), charWidth(cw), charHeight(ch), charPerRow(cpr), transparentColor{0,0,0} {}

Font *Font::CreateFont(const char *file, int charWidth, int charHeight)
{
	Assert(charWidth >= 8 && charHeight >= 8);
	Texture *tex = Game::GetTextures()->GetEntityByName(file);
	if (!tex) {
		Error("Unable to load font \"%s\"", file);
		return NULL;
	}
	Font *f = new Font(tex, charWidth, charHeight, tex->width / charWidth);
	return f;
}

Font *Font::CreateDefaultFont()
{
	return CreateFont("font.bmp", 8, 8);
}