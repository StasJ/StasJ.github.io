//
//  math.h
//  Game
//
//  Created by Stas Jaroszynski on 8/22/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__math__
#define __Game__math__

#define ToRadians(x) (x * 0.0174533f)
#define ToDegrees(x) (x * 57.2958f)
#define EPSILON 0.00000011920928955078125f

static inline float Lerp(float a, float b, float t)
{
	return (1 - t) * a + t * b;
}

static inline float Clamp(float x, float min, float max)
{
	return x < min ? min : x > max ? max : x;
}

#endif /* defined(__Game__math__) */
