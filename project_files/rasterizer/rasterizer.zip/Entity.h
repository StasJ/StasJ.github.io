//
//  Entity.h
//  Game
//
//  Created by Stas Jaroszynski on 8/16/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__Entity__
#define __Game__Entity__

#include "common.h"
#include "Vector.h"
#include "IEntity.h"

class Entity : public IEntity {
public:
	Vec3 pos;
	Vec3 rot;
	
	Model *model;
	bool isVisible;
	
	Entity();
	Entity(const char *name);
	void Draw();
	
	
};

#endif /* defined(__Game__Entity__) */
