//
//  EntityManager.cpp
//  Game
//
//  Created by Stas Jaroszynski on 8/14/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include "EntityManager.h"
#include "IEntity.h"
#include <vector>

EntityManager::~EntityManager()
{
	Clear();
}

IEntity *EntityManager::GetEntityByName(const char *name) const
{
	Assert(name != NULL);
	for (std::vector<IEntity *>::const_iterator it = entities.begin(); it != entities.end(); it++) {
		if ((*it)->NameMatches(name)) {
			return *it;
		}
	}
	Error("Entity \"%s\" not found", name);
	return NULL;
}

void EntityManager::AddEntity(IEntity *e)
{
	Assert(e);
	entities.push_back(e);
}

void EntityManager::ForEach(std::function<void (IEntity *e)> func)
{
	for (std::vector<IEntity *>::const_iterator it = entities.begin(); it != entities.end(); it++) {
		func(*it);
	}
}

void EntityManager::Clear()
{
	for (std::vector<IEntity *>::const_iterator it = entities.begin(); it != entities.end(); it++) {
		delete *it;
	}
	entities.clear();
}