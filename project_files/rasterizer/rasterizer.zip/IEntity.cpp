//
//  IEntity.cpp
//  Game
//
//  Created by Stas Jaroszynski on 8/14/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include "IEntity.h"

bool IEntity::NameMatches(const char *n) const
{
	if (!n)
		return false;
	for (int i = 0; i < ENTITY_NAME_MAX; i++) {
		if (name[i] != n[i])
			break;
		if (name[i] == 0 && n[i] == 0)
			return true;
	}
	return false;
}