//
//  g_common.h
//  Game
//
//  Created by Stas Jaroszynski on 8/16/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef Game_g_common_h
#define Game_g_common_h

#include "common.h"

typedef struct {float x, y;} vec2_t;
typedef struct {float x, y, z;} vec3_t;

typedef struct {
	ushort vertex;
	ushort uv;
	ushort normal;
	float light;
} vertexIndex_t;

typedef struct {
	vertexIndex_t a;
	vertexIndex_t b;
	vertexIndex_t c;
	uchar material;
} face_t;

typedef struct {
	uchar r;
	uchar g;
	uchar b;
	uchar a;
} pixel_t;

typedef struct {
	int width, height, dataSize;
	pixel_t *buffer;
} vid_t;

#ifdef RASTER_STATS
typedef struct {
	int triangles;
	int vertices;
} rasterizerStatitics_t;
#endif

#endif
