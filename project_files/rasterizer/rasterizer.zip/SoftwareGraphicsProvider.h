//
//  SoftwareGraphicsProvider.h
//  Game
//
//  Created by Stas Jaroszynski on 8/16/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__SoftwareGraphicsProvider__
#define __Game__SoftwareGraphicsProvider__

#include "common.h"
#include "IGraphicsProvider.h"
#include "Color.h"
#include "Matrix.h"
#include <list>
#include <stack>
#include "MemoryArena.h"
#include "Vector.h"

#define MAX_VERTS 10000
#define VERT_BUFFER_SIZE (MAX_VERTS * 4)

class SoftwareGraphicsProvider : public IGraphicsProvider
{
	static SoftwareGraphicsProvider *instance;
	
	vid_t vid;
	float *zBuff;
	
	struct {
		const Model *m;
		Vec4 vert[VERT_BUFFER_SIZE];
		int vertNum;
		Vec3 norm[VERT_BUFFER_SIZE];
		int normNum;
		Vec2 tex[VERT_BUFFER_SIZE];
		int texNum;
		
		std::list<face_t> faces;
		int faceNum;
		
		Texture *texture;
		
		char clippedV[MAX_VERTS];
	} rd;
	
#ifdef RASTER_STATS
	rasterizerStatitics_t stats;
#endif
	
	Color color;
	Font *font;
	
	Matrix mvp;
	Matrix projectionMatrix;
	Matrix transformMatrix;
	std::stack<Matrix> transformStack;
	
	uint enableMask;
	uint renderModeMask;
	uint clearMask;
	
	Vec3 Light0Dir;
	Vec4 Light0Pos;
	float Light0Ambient;
	int	 Light0Type;
	
	SoftwareGraphicsProvider();
	bool CreateVid(int width, int height);
	
	inline void ApplyModelView();
	inline void CullFaces();
	inline void FixNormals();
	inline void CalculateLighting();
	inline void ApplyProjection();
	inline void ClipToProjection();
	inline void DivideByW();
	inline void ToScreenSpace();
	inline void RasterizeTriangles();
	inline void RasterizeWireframe();
	
	void TopTriangle(vertexIndex_t v0, vertexIndex_t v1, vertexIndex_t v2);
	void BottomTriangle(vertexIndex_t v0, vertexIndex_t v1, vertexIndex_t v2);
	void ScanLine(int y, vertexIndex_t va, vertexIndex_t vb, vertexIndex_t vc, vertexIndex_t vd);
	void Triangle(vertexIndex_t v0, vertexIndex_t v1, vertexIndex_t v2);
	
public:
	static SoftwareGraphicsProvider *Instance();
	
	bool Init(int width, int height);
	bool Resize(int width, int height);
//	void SetOutput(uchar *data, int width, int height);
	
	void Color3f(float r, float g, float b);
	void Color1f(float brightness);
	void SetProjection(Matrix m);
	void SetTransform(Matrix m);
	void SetMVP(Matrix m);
	void CalculateMVP();
	void RenderMode(uint mode);
	void Enable(uint mode);
	void Disable(uint mode);
	
	Matrix PushTransform();
	void   PopTransform();
	
	void DrawModel(const Model *m);
	void Clear();
	void DrawString(float x, float y, const char *s, ...);
	
	void R_Fill(int x, int y, int w, int h);
	void R_Line(int x, int y, int x1, int y1);
	void R_Dot(int x, int y);
	void R_TexCopy(int x, int y, const Texture *t, int tx, int ty, int tw, int th);
	void R_DrawString(int x, int y, const char *s, ...);
	
	const	vid_t GetColorBuffer() const;
	void	SetColorBuffer();
	int		GetWidth() const;
	int		GetHeight() const;
	Matrix	GetTransform() const;
	void	SetLight0(Vec4 val, float ambient, int type);
	
	int tempTri = 0;
	
#ifdef RASTER_STATS
	rasterizerStatitics_t GetStats() const;
#endif
};

#endif /* defined(__Game__SoftwareGraphicsProvider__) */
