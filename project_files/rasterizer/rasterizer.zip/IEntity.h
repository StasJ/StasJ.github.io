//
//  IEntity.h
//  Game
//
//  Created by Stas Jaroszynski on 8/14/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Game__IEntity__
#define __Game__IEntity__

#include "common.h"

#define ENTITY_NAME_MAX 256

class IEntity {
public:
	char name[ENTITY_NAME_MAX];
	
	bool NameMatches(const char *) const;
};

#endif /* defined(__Game__IEntity__) */
