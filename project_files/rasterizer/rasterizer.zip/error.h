//
//  error.h
//  Rasterize Testing
//
//  Created by Stas Jaroszynski on 8/10/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#ifndef __Rasterize_Testing__error__
#define __Rasterize_Testing__error__

#ifdef NDEBUG
#define Assert(expr) ((void)0)
#else
#define Assert(expr) \
if (expr) {} else { printf("#Assertion \"%s\" failed in %s, line %d\n", #expr, __FILE__, __LINE__); __AssertBreakFunc(); }
#endif // NDEBUG

#define WarningIncompleteImplementation() Warning("%s %d: Incomplete implementation of \"%s\"", __FILE__, __LINE__, __FUNCTION__)
#define FatalIncompleteImplementation() Notice("%s %d: Incomplete implementation of \"%s\"", __FILE__, __LINE__, __FUNCTION__);exit(1)

void Log	(const char *s, ...);
void Notice	(const char *s, ...);
void Warning(const char *s, ...);
void Error  (const char *s, ...);
void Fatal  (const char *s, ...);
const char *StringFormat(const char *fmt, ...);
void __AssertBreakFunc();
void __Break();

#endif /* defined(__Rasterize_Testing__error__) */
