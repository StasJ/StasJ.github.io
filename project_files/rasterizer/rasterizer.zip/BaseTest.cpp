//
//  BaseTest.cpp
//  Game
//
//  Created by Stas Jaroszynski on 8/26/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#include "BaseTest.h"
#include "Game.h"
#include "IWindowProvider.h"
#include "IGraphicsProvider.h"
#include "Matrix.h"
#include "Vector.h"
#include "EntityDataCache.h"

static Model *m;
static float rotX = 0, rotY = 0, rotZ = 0, z = -5, y = 0, x = 0, far = 8;
static int renderMode = 0;
static void ProcessInput()
{
	const float deltaTime = Game::GetDeltaTime();
	if (Game::GetWindow()->IsPressed('1')) exit(0);
	if (Game::GetWindow()->IsPressed('a')) rotY += M_PI * deltaTime;
	if (Game::GetWindow()->IsPressed('d')) rotY -= M_PI * deltaTime;
	if (Game::GetWindow()->IsPressed('w')) rotX += M_PI * deltaTime;
	if (Game::GetWindow()->IsPressed('s')) rotX -= M_PI * deltaTime;
	if (Game::GetWindow()->IsPressed('q')) rotZ += M_PI * deltaTime;
	if (Game::GetWindow()->IsPressed('e')) rotZ -= M_PI * deltaTime;
	if (Game::GetWindow()->IsPressed('z')) z += M_PI * deltaTime;
	if (Game::GetWindow()->IsPressed('x')) z -= M_PI * deltaTime;
	if (Game::GetWindow()->IsPressed('c')) far += M_PI * deltaTime;
	if (Game::GetWindow()->IsPressed('v')) far -= M_PI * deltaTime;
	if (Game::GetWindow()->IsPressed(KEY_UP)) y += 4 * deltaTime;
	if (Game::GetWindow()->IsPressed(KEY_DOWN)) y -= 4 * deltaTime;
	if (Game::GetWindow()->IsPressed(KEY_RIGHT)) x += 4 * deltaTime;
	if (Game::GetWindow()->IsPressed(KEY_LEFT)) x -= 4 * deltaTime;
	
	if (Game::GetWindow()->IsPressed('2')) m = Game::GetModels()->GetEntityByName("tri.obj");
	if (Game::GetWindow()->IsPressed('3')) m = Game::GetModels()->GetEntityByName("quad.obj");
	if (Game::GetWindow()->IsPressed('4')) m = Game::GetModels()->GetEntityByName("cube.obj");
	if (Game::GetWindow()->IsPressed('5')) m = Game::GetModels()->GetEntityByName("skull.obj");
	if (Game::GetWindow()->IsPressed('6')) m = Game::GetModels()->GetEntityByName("column.obj");
	if (Game::GetWindow()->IsPressed('7')) m = Game::GetModels()->GetEntityByName("f16.obj");
	
	TOGGLE(Game::GetWindow()->IsPressed('r'), renderMode, 3);
}

void BaseTest::Init()
{
	//Game::GetModels()->LoadEntityFromFile("cube.obj")->texture = Game::GetTextures()->LoadEntityFromFile("cube.bmp");
	//Game::GetModels()->LoadEntityFromFile("f16.obj")->texture = Game::GetTextures()->LoadEntityFromFile("f16.bmp");
	m = Game::GetModels()->GetEntityByName("f16.obj");
}

void BaseTest::Update()
{
	ProcessInput();
	Game::GetGraphics()->RenderMode(renderMode == 0 ? G_FILL : renderMode == 1 ? G_WIREFRAME : G_FILL | G_WIREFRAME);
	Game::GetGraphics()->SetProjection(Matrix::Perspective(66, Game::GetWidth()/(float)Game::GetHeight(), 0.1, far));
	Game::GetGraphics()->SetTransform(Matrix::Translate(x, y, z) * Matrix::RotateY(rotY) * Matrix::RotateX(rotX) * Matrix::RotateZ(rotZ));
	Game::GetGraphics()->DrawModel(m);
}