//
//  HelloWorldLayer.h
//  N64_Controller2
//
//  Created by Stas Jaroszynski on 7/1/14.
//  Copyright Stas Jaroszynski 2014. All rights reserved.
//


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// HelloWorldLayer
@interface HelloWorldLayer : CCLayer

// returns a CCScene that contains the HelloWorldLayer as the only child
+(CCScene *) scene;

- (void)update:(ccTime)delta;

@end
