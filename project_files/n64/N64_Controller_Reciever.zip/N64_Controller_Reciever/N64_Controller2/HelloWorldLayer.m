//
//  HelloWorldLayer.m
//  N64_Controller2
//
//  Created by Stas Jaroszynski on 7/1/14.
//  Copyright Stas Jaroszynski 2014. All rights reserved.
//


// Import the interfaces
#import "HelloWorldLayer.h"
#import "ControllerDelegate.h"
#import "ArduinoSerial.h"

@interface HelloWorldLayer() {
	ControllerDelegate *controllerDelegate;
	int port;
}
@end

// HelloWorldLayer implementation
@implementation HelloWorldLayer

+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
	HelloWorldLayer *layer = [HelloWorldLayer node];
	[scene addChild: layer];
	return scene;
}

-(id) init
{
	if( (self=[super init]) ) {
		controllerDelegate = [[ControllerDelegate alloc] init];
		port = serialport_init("/dev/tty.usbmodemfa131", 115200);
		[self schedule:@selector(update:)];
	}
	return self;
}

- (void)update:(ccTime)delta
{
	char command;
	if (serialport_read(port, &command, 0)) {
		if (command == 0x01) {
			serialport_write(port, [controllerDelegate N64_controllerData], 4);
		}
	}
}

- (void) dealloc
{
	serialport_close(port);
	[super dealloc];
}

@end
