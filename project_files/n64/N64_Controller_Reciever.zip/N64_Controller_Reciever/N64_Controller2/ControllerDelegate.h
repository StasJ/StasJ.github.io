//
//  ControllerDelegate.h
//  N64_Controller
//
//  Created by Stas Jaroszynski on 7/1/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <DDHidLib/DDHidLib.h>

#define PS4_BTN_X 1
#define PS4_BTN_SQUARE 0
#define PS4_BTN_TRIANGLE 3
#define PS4_BTN_CIRCLE 2
#define PS4_BTN_L1 4
#define PS4_BTN_L2 6
#define PS4_BTN_R1 5
#define PS4_BTN_R2 7
#define PS4_BTN_OPTIONS 9
#define PS4_BTN_SHARE 8
#define PS4_D_LEFT 0
#define PS4_D_RIGHT 1
#define PS4_D_UP 2
#define PS4_D_DOWN 3

#define N64_BTN_A 7
#define N64_BTN_B 6
#define N64_BTN_Z 5
#define N64_BTN_START 4
#define N64_BTN_UP 3
#define N64_BTN_DOWN 2
#define N64_BTN_LEFT 1
#define N64_BTN_RIGHT 0
#define N64_BTN_SHOULDER_L 5
#define N64_BTN_SHOULDER_R 4
#define N64_BTN_C_UP 3
#define N64_BTN_C_DOWN 2
#define N64_BTN_C_LEFT 1
#define N64_BTN_C_RIGHT 0

#define ANALOG_MAX 65536

@interface ControllerDelegate : NSObject {
	NSArray *allJoysticks;
	
	DDHidJoystick *joystick;
	int joystickIndex;
	
	int xAxis;
	int yAxis;
	int numButtons;
	BOOL buttons[128];
	BOOL dPad[4];
	BOOL cPad[4];
	char xAxis_N64;
	char yAxis_N64;
	
	char N64_controllerData[4];
}

- (char *)updateN64ControllerData;
- (char *)N64_controllerData;

@end
