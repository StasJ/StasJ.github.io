//
//  AppDelegate.h
//  N64_Controller2
//
//  Created by Stas Jaroszynski on 7/1/14.
//  Copyright Stas Jaroszynski 2014. All rights reserved.
//

#import "cocos2d.h"

@interface N64_Controller2AppDelegate : NSObject <NSApplicationDelegate>
{
	NSWindow	*window_;
	CCGLView	*glView_;
}

@property (assign) IBOutlet NSWindow	*window;
@property (assign) IBOutlet CCGLView	*glView;

- (IBAction)toggleFullScreen:(id)sender;

@end
