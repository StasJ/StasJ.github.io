//
//  ControllerDelegate.m
//  N64_Controller
//
//  Created by Stas Jaroszynski on 7/1/14.
//  Copyright (c) 2014 Stas Jaroszynski. All rights reserved.
//

#import "ControllerDelegate.h"

@implementation ControllerDelegate

- (id)init
{
	self = [super init];
	if (self) {
		allJoysticks = [[DDHidJoystick allJoysticks] retain];
		[allJoysticks makeObjectsPerformSelector:@selector(setDelegate:) withObject:self];
		
		if ([allJoysticks count] > 0)
			[self setJoystickIndex:0];
		else
			NSLog(@"No Controllers found!");
	}
	return self;
}

- (void)setJoystickIndex: (unsigned int)index
{
	if (joystick != nil) {
		[joystick stopListening];
		joystick = nil;
	}
	joystickIndex = index;
	if (joystickIndex != -1)
	{
		joystick = [allJoysticks objectAtIndex:joystickIndex];
		[joystick startListening];
		
		numButtons = (int)[[joystick buttonElements] count];
		for (int i = 0; i < numButtons; i++)
			buttons[i] = 0;
	}
}

- (char *)updateN64ControllerData
{
	N64_controllerData[0] = 0;
	N64_controllerData[1] = 0;
	N64_controllerData[2] = xAxis_N64;
	N64_controllerData[3] = yAxis_N64;
	
	N64_controllerData[0] |= buttons[PS4_BTN_X] << N64_BTN_A;
	N64_controllerData[0] |= buttons[PS4_BTN_SQUARE] << N64_BTN_B;
	N64_controllerData[0] |= (buttons[PS4_BTN_L2] | buttons[PS4_BTN_R2]) << N64_BTN_Z;
	N64_controllerData[0] |= buttons[PS4_BTN_OPTIONS] << N64_BTN_START;
	N64_controllerData[0] |= dPad[PS4_D_UP] << N64_BTN_UP;
	N64_controllerData[0] |= dPad[PS4_D_DOWN] << N64_BTN_DOWN;
	N64_controllerData[0] |= dPad[PS4_D_LEFT] << N64_BTN_LEFT;
	N64_controllerData[0] |= dPad[PS4_D_RIGHT] << N64_BTN_RIGHT;
	
	N64_controllerData[1] |= buttons[PS4_BTN_L1] << N64_BTN_SHOULDER_L;
	N64_controllerData[1] |= buttons[PS4_BTN_R1] << N64_BTN_SHOULDER_R;
	N64_controllerData[1] |= cPad[N64_BTN_C_UP] << N64_BTN_C_UP;
	N64_controllerData[1] |= cPad[N64_BTN_C_DOWN] << N64_BTN_C_DOWN;
	N64_controllerData[1] |= cPad[N64_BTN_C_LEFT] << N64_BTN_C_LEFT;
	N64_controllerData[1] |= cPad[N64_BTN_C_RIGHT] << N64_BTN_C_RIGHT;
	
	return N64_controllerData;
}

- (char *)N64_controllerData
{
	return N64_controllerData;
}

#pragma mark - Joystick callbacks

- (void)ddhidJoystick:(DDHidJoystick *)joystick buttonDown:(unsigned)buttonNumber
{
	buttons[buttonNumber] = 1;
	[self updateN64ControllerData];
}

- (void)ddhidJoystick:(DDHidJoystick *)joystick buttonUp:(unsigned)buttonNumber
{
	buttons[buttonNumber] = 0;
	[self updateN64ControllerData];
}


#define THRESHOLD   2<<13

- (void)ddhidJoystick:(DDHidJoystick *)joystick
                stick:(unsigned)stick
             xChanged:(int)value
{
	xAxis = value;
	xAxis_N64 = value * 80 / ANALOG_MAX;
	[self updateN64ControllerData];
}

- (void)ddhidJoystick:(DDHidJoystick *)joystick
                stick:(unsigned)stick
			 yChanged:(int)value
{
	yAxis = value;
	yAxis_N64 = -value * 80 / ANALOG_MAX;
	[self updateN64ControllerData];
}

- (void)ddhidJoystick:(DDHidJoystick *)joystick stick:(unsigned int)stick otherAxis:(unsigned int)otherAxis valueChanged:(int)value
{
	if (otherAxis == 0) {
		if(value < -THRESHOLD) {
			cPad[N64_BTN_C_LEFT] = 1;
			cPad[N64_BTN_C_RIGHT] = 0;
		} else if(value > THRESHOLD) {
			cPad[N64_BTN_C_LEFT] = 0;
			cPad[N64_BTN_C_RIGHT] = 1;
		} else {
			cPad[N64_BTN_C_LEFT] = 0;
			cPad[N64_BTN_C_RIGHT] = 0;
		}
	} else if (otherAxis == 1) {
		if (value < -THRESHOLD) {
			cPad[N64_BTN_C_DOWN] = 0;
			cPad[N64_BTN_C_UP] = 1;
		} else if(value > THRESHOLD) {
			cPad[N64_BTN_C_DOWN] = 1;
			cPad[N64_BTN_C_UP] = 0;
		} else {
			cPad[N64_BTN_C_DOWN] = 0;
			cPad[N64_BTN_C_UP] = 0;
		}
	}
}

- (void) ddhidJoystick:(DDHidJoystick *)joystick stick:(unsigned int)stick povNumber:(unsigned int)povNumber valueChanged:(int)value
{
	switch (value) {
		case -1:
			dPad[PS4_D_UP]		= 0;
			dPad[PS4_D_DOWN]	= 0;
			dPad[PS4_D_RIGHT]	= 0;
			dPad[PS4_D_LEFT]	= 0;
			break;
			
		case 0:
			dPad[PS4_D_UP]		= 1;
			dPad[PS4_D_DOWN]	= 0;
			dPad[PS4_D_RIGHT]	= 0;
			dPad[PS4_D_LEFT]	= 0;
			break;
			
		case 4500:
			dPad[PS4_D_UP]		= 1;
			dPad[PS4_D_DOWN]	= 0;
			dPad[PS4_D_RIGHT]	= 1;
			dPad[PS4_D_LEFT]	= 0;
			break;
			
		case 9000:
			dPad[PS4_D_UP]		= 0;
			dPad[PS4_D_DOWN]	= 0;
			dPad[PS4_D_RIGHT]	= 1;
			dPad[PS4_D_LEFT]	= 0;
			break;
			
		case 13500:
			dPad[PS4_D_UP]		= 0;
			dPad[PS4_D_DOWN]	= 1;
			dPad[PS4_D_RIGHT]	= 1;
			dPad[PS4_D_LEFT]	= 0;
			break;
			
		case 18000:
			dPad[PS4_D_UP]		= 0;
			dPad[PS4_D_DOWN]	= 1;
			dPad[PS4_D_RIGHT]	= 0;
			dPad[PS4_D_LEFT]	= 0;
			break;
			
		case 22500:
			dPad[PS4_D_UP]		= 0;
			dPad[PS4_D_DOWN]	= 1;
			dPad[PS4_D_RIGHT]	= 0;
			dPad[PS4_D_LEFT]	= 1;
			break;
			
		case 27000:
			dPad[PS4_D_UP]		= 0;
			dPad[PS4_D_DOWN]	= 0;
			dPad[PS4_D_RIGHT]	= 0;
			dPad[PS4_D_LEFT]	= 1;
			break;
			
		case 31500:
			dPad[PS4_D_UP]		= 1;
			dPad[PS4_D_DOWN]	= 0;
			dPad[PS4_D_RIGHT]	= 0;
			dPad[PS4_D_LEFT]	= 1;
			break;
			
		default:
			break;
	}
	[self updateN64ControllerData];
}

@end
