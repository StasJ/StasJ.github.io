#!/usr/bin/env python3.4
import time
import http.server
import re
import os
import sys
import io
import sqlite3
from itertools import chain
import urllib.parse

os.chdir(os.path.dirname(os.path.realpath(__file__)))
HOST_NAME = "localhost"
PORT_NUMBER = 8080

class RequestHandler(http.server.BaseHTTPRequestHandler):
    database = sqlite3.connect('data')
    def do_HEAD(s):
        s.send_response(200)
        s.send_header("Content-type", "text/html")
        s.end_headers()
    def do_GET(s):
        path = re.split("\?", s.path, maxsplit=1)
        get = None
        if len(path) == 2:
            path[1] = urllib.parse.unquote(path[1])
            get = dict()
            while True:
                start = path[1].index('=')
                try: end = path[1].index('&')
                except ValueError: end = len(path[1])
                key = path[1][0:start]
                val = path[1][start+1:end]
                get[key] = val
                if end != len(path[1]):
                    path[1] = path[1][end+1:]
                else:
                    break;
        path = path[0]
        realpath = "web" + path

        if os.path.isfile(realpath):
            if realpath[realpath.rindex('.'):] == ".phtml":
                RequestHandler.sendPHTML(realpath, s, get)
            else:
                RequestHandler.sendFile(realpath, s)
        elif os.path.isdir(realpath):
            if "index.html" in os.listdir(realpath):
                RequestHandler.sendFile(realpath + "index.html", s)
            elif "index.phtml" in os.listdir(realpath):
                RequestHandler.sendPHTML(realpath + "index.phtml", s, get)
            else:
                RequestHandler.sendPHTML("web/config/dir.phtml", s, get, {"DIRECTORY" : path}, realpath)
        else:
            RequestHandler.sendPHTML("web/config/404.phtml", s, get, {"WRONG_PATH" : path})
        
    def sendFile(path, s):
        with open(path, mode="rb") as file:
            content = file.read()
            s.send_response(200)
            s.send_header("Content-type", "text/html")
            s.end_headers()
            s.wfile.write(content)

    def sendString(string, s):
            s.send_response(200)
            s.send_header("Content-type", "text/html")
            s.end_headers()
            s.wfile.write(bytes(string, "UTF-8"))

    def sendPHTML(path, s, get, env=dict(), workpath=None):
        RequestHandler.sendString(RequestHandler.parsePHTML(path, get, env, workpath), s)

    def parsePHTML(path, get=[], env=dict(), workpath=None):
        with open (path, "r") as file:
            data = file.read()
            cursor = RequestHandler.database.cursor()
            if not workpath:
                workpath = os.path.dirname(path)
            if path[:3] == "web":
                path = path[3:]
            curpath = os.getcwd()
            def query(q, v=tuple()):
                cursor.execute(q, v)
                return cursor.fetchall()
            def importP(p):
                print(RequestHandler.parsePHTML(p, get, env, workpath))
            envDict = dict(chain({"QUERY" : query, "GET" : get, "IMPORT" : importP, "PATH" : path}.items(), env.items()))

            phtml = re.search("<\?.*?\?>", data, re.DOTALL)
            while phtml:
                codeOut = io.StringIO()
                code = phtml.group(0)[2:len(phtml.group(0))-2]
                os.chdir(curpath + "/" + workpath)
                curStdout = sys.stdout
                curStderr = sys.stderr
                sys.stdout = codeOut
                sys.stderr = codeOut
                try:
                    exec(code, envDict)
                    RequestHandler.database.commit()
                except Exception as e:
                    print(type(e))
                    print(e)
                    print("</class>")
                sys.stdout = curStdout
                sys.stderr = curStderr
                os.chdir(curpath)
                data = data[:phtml.start(0)] + codeOut.getvalue() + data[phtml.end(0):]
                phtml = re.search("<\?.*?\?>", data, re.DOTALL)
            return data


if __name__ == "__main__":
    httpd = http.server.HTTPServer((HOST_NAME, PORT_NUMBER), RequestHandler)
    print(time.asctime(), "Server Started - %s:%s" % (HOST_NAME, PORT_NUMBER))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    httpd.server_close()
    print("Server Stopped")
