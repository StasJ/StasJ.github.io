#define TIMER_START TCCR1A = 0;TCCR1B = 0;TCNT1  = 0;TCCR1B = 1
#define TIMER_START_8 TCCR1A = 0;TCCR1B = 0;TCNT1  = 0;TCCR1B = (1 << CS11)
#define TIMER_END TCCR1B = 0
#define TIME TCNT1

#define EVAL(...) __VA_ARGS__
#define PRESCALE_1 (1 << CS10)
#define PRESCALE_8 (1 << CS11)
#define PRESCALE_64 ((1 << CS10) | (1 << CS11))
#define PRESCALE_256 (1 << CS12)

#define TIMER1_INTERRUPT(del, pre) \
  cli();                      \
  TCCR1A = 0;                 \
  TCCR1B = 0;                 \
  TCNT1 = 0;                  \
                              \
  OCR1A = del;                \
  TCCR1B |= (1 << WGM12);     \
  TCCR1B |= EVAL(PRESCALE_ ## pre);      \
  TIMSK1 |= (1 << OCIE1A);    \
  sei();

#define INTERRUPT1_CALLBACK() ISR(TIMER1_COMPA_vect)
#define INTERRUPT1_DISABLE() TCCR1B = 0;TIMSK1 &= ~(1 << OCIE1A);

#define DEBUG
#ifdef DEBUG
  #define dp(x) Serial.print(x)
  #define dpv(x) Serial.print(#x);Serial.print(": ");Serial.println(x)
  #define debug(x) x
  
  #define TIMER_MEASURE(x) TIMER_START;x;TIMER_END;Serial.write(0xd3);/*Serial.print(#x);*/Serial.print("\nTime: ");Serial.println(TIME - 2)
#else
  #define dp(x)
  #define dpv(x)
  #define debug(x)
  #define TIMER_MEASURE(x) x
#endif
